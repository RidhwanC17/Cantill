# APPROACH

## AI tools used (disclosure)

* **Claude (Anthropic)** was used as a pair-programming assistant while building this repo: exploratory analysis,
  drafting and reviewing code, and writing the tests and docs. I reviewed the design decisions in DECISIONS.md.
* **ChatGPT (OpenAI)** was used in the final code review to identify and fix edge cases in unseen-company
  classification and automatic record-ID inference, and to add regression tests and update the documentation.
* **Inside the tool:** an *optional* Anthropic API call (`src/spendpipe/llm.py`) classifies lines into the tree when
  `ANTHROPIC_API_KEY` is set. It is off when there is no key. No other model or external service is used; there are
  no downloaded model weights. Everything else is pandas, scikit-learn and RapidFuzz.

## Design in one page

The tool is a pipeline whose only company-specific input is a YAML file. Stages:

1. **Ingest.** Every source file is read as strings and mapped onto one canonical record table. Amounts parse
   `1,234.56`, `1.234,56`, `(123)`, `123-`; dates parse ISO, `dd/mm/yyyy`, `dd-Mon-yy`, compact and Excel serials, and
   impossible dates are flagged, never guessed. PO references (`4510085877/10.0`, `PO#...`, `PO ...`) reduce to the
   digit run and PO item; invoice numbers reduce to their core digits.
2. **Net spend in the reporting currency.** Gross amounts lose VAT at the stated rate (15% when blank, explicit 0
   respected). Non-USD lines use the row's rate (units per USD), else the FX table for the invoice month (nearest
   available month when the table has a gap); USD lines are never converted.
3. **Exclusions** with the brief's four codes, in priority order CANCELLED, NOT_APPROVED, NON_PROCUREMENT, DUPLICATE.
   Status vocabularies and non-procurement lexicons (intercompany, tax, royalty, financing, payroll, partner
   billing...) are generic and extensible per config; a short-text guard stops a product description that merely
   contains a word such as "duty" from being excluded.
4. **Cross-system matching (A).** Five stages, each only on what the previous left over: PO + net amount (one-to-one
   by text/quantity/PO-item score); same PO + same text + same unit price (partial or combined invoices of receipts
   already counted); supplier + amount + text when the PO is missing or unusable; one invoice line settling several
   receipts; leftover identical copies of a line (an invoice exported twice). Lines with different PO items are
   different lines, so genuine multi-line invoices are not collapsed.
5. **Supplier resolution.** Union-find over shared vendor IDs and equal normalised names (legal suffixes removed,
   spaces collapsed so OCR breaks vanish), plus a conservative fuzzy merge with an OCR digit/letter fold.
6. **Item resolution.** Material code is the identity; codes carrying identical long specific text merge; lines
   without a code cluster on text within a supplier; cross-system matches inherit the primary record's keys.
7. **Classification** into leaf paths of the tree file (names exactly as in the file; any depth, `l1..l4`+).
   * *Zero-shot offline:* char- and word-level TF-IDF similarity between the line (description, account text,
     supplier) and a pseudo-document per leaf (leaf name weighted most, ancestors less).
   * *Consistency + self-training:* same-item and (weakly) same-supplier lines share evidence; the most confident
     lines of each category train a linear model over the whole corpus whose predictions are blended back in.
   * *LLM (optional):* sees the whole tree as a numbered list, returns one leaf + confidence per signature; blended
     as probabilities; every failure falls back to the local model.
   * *Supervised memory (optional):* when a labelled history of the same company exists (A's labels, B's seed
     labels) a TF-IDF model plus exact item-code memory is trained on it and used for fresh data from that company.
   * Confidence is a function of the final probability and margin; lines decided by the offline model alone are
     compressed because they are measurably less reliable than their raw score.

## Measured results (development data; labels are local)

| What | Result |
|---|---|
| A: tool -> ERP matching | 28,520 tool lines: 23,696 DUPLICATE (PO+amount 16,672; supplier+amount+text 5,579; partial invoices 830; exported twice 614; multi-receipt 1), 315 NOT_APPROVED, 188 CANCELLED. No ground truth for tool lines; stage 3 validated by hiding the PO on half of the PO-matched lines: 96% recovered or amount-equivalent, 3.9% missed, 0.8% wrong. |
| A: supplier grouping vs golden | pairwise F1 0.982, B-cubed F1 0.989 (74 groups vs 70) *with the master-data behaviour in D-7* (0.18 without it) |
| A: item grouping vs golden | pairwise F1 0.9999, B-cubed 0.996 |
| B: spend determination vs 3,000 seed labels | inclusion agreement 99.97%; the 450 non-procurement seed lines are all found, 1 disagreement (a duplicate rule hit) |
| Classification, **zero labels, no LLM** (A hidden labels / B seed) | leaf accuracy 0.19 / 0.36; L1 0.53 / 0.56; spend-weighted leaf 0.38 / 0.46 |
| Classification with supervised memory, held-out A lines | leaf 0.92 (random split), 0.85 (unseen items); L1 0.97; confidence well calibrated (conf >= 0.7: 99% correct) |
| Classification with the LLM layer | **not measured** against the live API (no key in the build environment). Integration, parsing, caching and fallback are tested against a mock client; with a mock that is 85% right the pipeline returns 78% overall. |

The honest reading of the zero-label numbers: tree names alone are a weak signal for abbreviated purchase text
(a terse engineering abbreviation vs a plain-language category name share almost no characters), which is why Company C relies on the LLM layer when a key is
available and the offline model is only a floor.

## Robustness checks added before submission

* Word-level TF-IDF vectorizers explicitly preserve the uppercase normalisation used by the parser. This avoids an empty vocabulary when an unseen company has alphabetic-only descriptions and taxonomy labels (rather than the numeric codes present in some development data).
* Automatic record-ID inference now gives priority to transaction/line/record identifiers and rejects entity identifiers such as `vendor_id` and `supplier_id` as row keys. When no reliable row key exists, ingestion falls back to a deterministic row number.
* Regression tests cover alphabetic-only zero-shot classification and the distinction between a line ID and a unique vendor ID. The synthetic Company C end-to-end smoke test also completes with the local classifier and no API key.

## Reproducing

`python -m pytest -q tests` (synthetic data), then the commands in README.md. `evaluate.py` scores an output file
against the local labels.
