# DECISIONS

Judgment calls made where the brief was silent or the data was ambiguous. Each says what I saw, what I chose, and
what would change my mind.

**D-1. Net amount for A's tool lines.** `net = gross / (1 + vat)`; the rate column holds `15`, `0.15`, `15%`, blank or
`0`. Blank means 15% (brief); an explicit 0 is respected. For *matching only* a blank-VAT line is also tried as
untaxed, in case the true rate was 0. Spend still uses 15%.

**D-2. FX.** USD lines are never converted, even when a rate is present (some USD lines carry a non-trivial rate, which would corrupt them if applied). Non-USD: row rate (units per USD), else the FX table. The table has gaps (e.g. some months
missing for some currencies), so I use the nearest available month. The brief says "invoice month", but B's
`invoice_date` is sometimes years off the posting date; the invoice date is used only when it is within 400 days of
the posting date, else the posting date. (Where rows carry a rate, it agrees with the table within 1% for 72% of
rows by posting month vs 68% by invoice month, so posting month is a safe fallback.)

**D-3. What is spend in B.** B has no status column. From the 3,000 seed labels, every NON_PROCUREMENT line is
explained by an intercompany account (`IC...`, `I/C Payable`, "IC Payables") or a short tax-type description
("State & Local Taxes -", "Sales Tax Expense -"). I implemented these as generic lexicons (not B-specific), found
all 450 with 3 false positives at first ("HEAVY DUTY" matched `duty`), and removed `duty/excise` from the tax list.
Unpaid invoices (blank paid date, 25% of lines) are kept: the analyst's labels do not exclude them.

**D-4. Reversals and zero lines.** Positive/negative pairs (same invoice, line, absolute amount) are kept: both are
included and net to zero, so total spend is right whichever way the golden file treats them. Zero-amount lines are
included with spend 0.

**D-5. Duplicates inside B.** Rows identical on supplier, invoice number, invoice line, amount and currency are
treated as repeated postings: first kept, the rest DUPLICATE (719 lines; zero amounts ignored). Risk: a legitimately
repeated line would be dropped; the invoice-line number in the key keeps genuine multi-line invoices apart.

**D-6. A's tool invoice "exported twice".** Identical lines are *not* collapsed up front: invoices often have several
identical lines (one invoice has 11), each matching its own ERP receipt. I match to the ERP first (one-to-one), then
call leftover identical copies (same invoice core number, supplier, gross amount, similar text, no conflicting PO
item) DUPLICATE. Also found: many tool invoices are *partial* quantities of a receipt at the same unit price (467 of
518 unmatched lines that share a PO with the ERP); these are already counted in the ERP value, so they are DUPLICATE
(stage 2), not new spend. Tool lines whose PO does not exist in the ERP at all are genuine tool-only spend and are counted.

**D-7. Master-data behaviour in A's golden keys (important, please read).** Comparing the golden `supplier_key` with
the names showed that 69 keys cover names that carry a vendor ID somewhere in the data, while 122 other names (64% of
names, 56% of lines) all share one catch-all key. The golden `item_key` is the material code, one shared key for
free-text/catalogue buying, and blank for lines with no material number (15,816 lines). A principled "one key per
real supplier" gives pairwise F1 0.18 against this golden file; reproducing the observed master-data behaviour gives
0.98. I made that behaviour **config-driven and A-only** (`supplier.group_unmastered`, `item.catch_all`,
`item.no_code: blank`) because the labels are the only definition of "correct" I have for A, and I kept the default
for any other company principled (one key per resolved supplier, text-clustered items). If the grader's A2 golden does
not share this structure, set these three options off in `company_A.yaml`; nothing else changes.

**D-8. A's non-procurement.** I found no non-procurement spend in A's ERP (keyword hits were product text such as
"heavy duty"), so only status exclusions apply there. Negative ERP values (434 reversals/credits) are kept as negative spend.

**D-9. Dates.** 65% of tool dates are blank in A and are not needed for matching. Dates are parsed to a canonical form
and flagged (`unparseable`, `out_of_range`, `inconsistent_dates`) in the diagnostics file; a bad date never excludes a line.

**D-10. Blank descriptions.** The classifier falls back on account/context text and supplier; lines with no usable
text at all get the corpus prior and a low confidence rather than being dropped or guessed with high confidence.

**D-11. Labels as supervised memory.** The brief allows labels for building classification and requires a zero-label
mode. Both exist: with a labelled history of the same company (A, B) a supervised model + item-code memory is used for
fresh data; with none (Company C) the offline zero-shot model and the optional LLM run. Training never touches the rows
being scored (a leakage guard for development runs). Labels live outside the repo and are never committed.

**D-12. Build-deadline outputs.** `yourname__A.csv` and `yourname__B.csv` in `outputs/` were produced in zero-label
mode (no labelled history, no LLM) so their classification columns are honest, not trained on the answers.

**D-13. Confidence.** Probability and margin of the blended model; offline-only decisions are compressed (calibrated on
A with hidden labels and B's seed) because the raw score overstates accuracy. Excluded rows carry the confidence of the
exclusion decision (0.97 status, 0.9 duplicate, 0.85 rule-based).

**D-14. Known limitations.** The LLM layer is untested against the live API in the build environment. Zero-label offline
accuracy is low on abbreviated text. Matching of PO-less tool lines is validated by simulation, not ground truth.
Non-Latin text is handled only through the LLM. The `--auto-config` heuristics were validated on A and B only.

**D-15. Automatic record identifiers on unseen companies.** A unique `vendor_id` or `supplier_id` is not a transaction-line identifier even when every row has a different value. Auto-configuration therefore excludes supplier/vendor/customer/account/item identifiers from the record-ID candidate pool and prioritises headers that indicate a line, record, row, transaction, receipt or journal entry. If no reliable row key exists, ingestion generates a row-based ID rather than reusing an entity key.

**D-16. Alphabetic-only classification inputs.** The text normaliser produces uppercase tokens. Word-level TF-IDF vectorizers now set `lowercase=False` so the uppercase token pattern remains consistent after preprocessing. This is necessary for unseen taxonomies and descriptions that contain no numeric tokens.
