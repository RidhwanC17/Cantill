# Spend pipeline (Cantill.ai Data & ML task, Round 1)

One config-driven tool that takes a company's raw purchase data and its category tree, decides what counts as
spend, matches records across systems, de-duplicates suppliers and items, and classifies every line into the
company's own tree. A new company needs a new **config**, never new code.

```
ingest -> amounts (net of tax, FX) -> exclusions -> cross-system matching -> supplier + item resolution
       -> classification (tree read at run time) -> one output row per input record
```

## Quick start

```bash
pip install -r requirements.txt
# put the confidential kit files under data/ (gitignored), e.g. data/company_A/..., data/company_B/...

python main.py --config configs/company_A.yaml --name yourname            # -> outputs/yourname__A.csv
python main.py --config configs/company_B.yaml --name yourname            # -> outputs/yourname__B.csv
python evaluate.py --config configs/company_A.yaml --output outputs/yourname__A.csv   # dev scoring vs labels
python -m pytest -q tests                                                  # 23 tests, synthetic data only
```

Runtime: ~30 s for A (65k records), ~20 s for B (41k lines), well inside the 60 min / 25k lines budget.

### Blind test (fresh data, frozen code)

```bash
export ANTHROPIC_API_KEY=...        # optional but strongly recommended for Company C (see "LLM layer")
bash scripts/run_blind.sh /path/to/new_A /path/to/new_B /path/to/company_C  yourname
```

which runs

```bash
python main.py --config configs/company_A.yaml --data-dir /path/to/new_A --tag A2 --name yourname
python main.py --config configs/company_B.yaml --data-dir /path/to/new_B --tag B2 --name yourname
python main.py --auto-config /path/to/company_C --tag C --name yourname    # writes configs/company_C.yaml, then runs it
```

`--auto-config` infers the column mapping from headers and values and writes an ordinary YAML file. If a
mapping is wrong, edit that YAML (data, not code) and re-run with `--config configs/company_C.yaml`.
Files whose names differ from the originals: `--source-file erp=new_name.csv`.

## Output

`<name>__<tag>.csv` with exactly the template columns:
`record_id, include, exclusion_reason, supplier_key, item_key, spend, l1..l4, confidence`.
One row per input record (both systems for A). Excluded rows keep their keys, have `spend = 0`, blank
categories, and a confidence for the exclusion decision. `outputs/diagnostics_<tag>.csv` (not part of the
submission) records which rule, match stage and FX path decided each row.

## LLM layer (optional) and what a run costs

If `ANTHROPIC_API_KEY` is set, the classifier sends *unique line signatures* (description + account text +
supplier) in batches of 40 together with the numbered leaf list of the tree file, and receives one leaf number
plus a confidence per line. The result is blended with the local model as probabilities. Without a key (or on any
API failure) the offline local classifier is used for those lines, so the tool always runs unattended.

* model: `CANTILL_LLM_MODEL` env var or `classification.llm_model` in the config (default `claude-haiku-5-5`)
* cost estimate (not measured against the live API from the build environment): about 4k input + 1k output tokens
  per batch of 40 signatures; 25,000 lines with roughly 12-15k unique signatures is ~350 calls, i.e. low single-digit US
  dollars on a Haiku-class model, more on larger models. A disk cache (`.cache/`, gitignored) makes reruns free.
* `--llm off` forces the offline path; `--llm on` warns if no key is present.

## Config reference (configs/company_*.yaml)

| key | meaning |
|---|---|
| `reporting_currency`, `default_vat`, `day_first` | reporting currency; VAT used when a gross amount has a blank rate; ambiguous `dd/mm` order |
| `sources[]` | one entry per file: `file`, `record_id{column,prefix}`, `amount_basis` (net/gross), `amount_in_reporting_currency`, `columns{amount,currency,rate,date,invoice_date,supplier_name,supplier_id,description,item_code,quantity,po,po_item,invoice_number,vat_rate,status_raw,doc_type,account_text,context}` |
| `combine` | `single`, or `two_system{primary, secondary}`: a secondary record matching a primary one is DUPLICATE |
| `fx` | FX table `{file,currency,month,rate,date_priority,max_invoice_gap_days}` (rates are units per USD) |
| `status` | approved / cancelled vocabularies (generic ones are built in) |
| `exclusions.nonprocurement` | extra `rules[{name,fields,pattern}]`, `disable[]`, `supplier_ids[]` on top of the built-in generic lexicons |
| `exclusions.duplicate_within_source` | exact-key duplicate rule inside one source (used for B) |
| `matching` | tolerances, text/supplier similarity thresholds, `dedupe_secondary_copies` |
| `supplier`, `item` | fuzzy thresholds; optional master-data behaviours (`group_unmastered`, `catch_all`, `no_code`) |
| `taxonomy` | `file`, `levels` (auto-detected when omitted; any depth) |
| `labels` | optional `dir/file` of labelled history, used as supervised memory only when it exists |
| `classification` | model parameters, `llm_model`, `llm_batch_size`, `llm_budget_seconds`, `domain_hint` |

## Layout

```
main.py  evaluate.py            CLI, dev scorer
configs/                        company_A.yaml, company_B.yaml (+ company_C.yaml at the blind test)
src/spendpipe/                  ingest, parsing, spend, matching, entities, taxonomy, classify, supervised, llm,
                                autoconfig, pipeline, metrics
tests/                          pytest on a synthetic company (no confidential data)
APPROACH.md  DECISIONS.md       method + every judgment call
```

The data files are never committed (`data/` is gitignored). Labels are used only locally.
