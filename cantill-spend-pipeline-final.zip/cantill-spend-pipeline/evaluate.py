#!/usr/bin/env python3
"""Score an output file against the local labels (development only; labels are confidential and never committed).

    python evaluate.py --config configs/company_A.yaml --output outputs/ridhwan__A.csv
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from spendpipe.config import load_config  # noqa: E402
from spendpipe.ingest import read_table  # noqa: E402
from spendpipe.metrics import cluster_scores  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    cfg = load_config(a.config)
    lc = cfg["labels"]
    lab = read_table(Path(cfg["_data_dir"]) / lc["file"]).set_index(lc["id"])
    out = pd.read_csv(a.output, dtype=str, keep_default_na=False).set_index("record_id")
    j = out.join(lab, how="inner", rsuffix="_gold")
    print(f"{len(j):,} labelled rows scored ({a.output})")
    lv = lc["levels"]
    inc = j[j["include"] == "1"]
    if len(inc):
        for k, col in enumerate(lv):
            ok = inc[f"l{k + 1}"] == inc[col]
            print(f"  category L{k + 1} accuracy: {ok.mean():.3f}  (n={len(inc):,})")
        spend = inc["spend"].astype(float).abs()
        ok = inc["l%d" % len(lv)] == inc[lv[-1]]
        print(f"  deepest-level accuracy, spend-weighted: {np.average(ok, weights=spend):.3f}")
        conf = inc["confidence"].astype(float)
        print("  calibration (confidence bin -> accuracy, n):")
        for lo, hi in [(0, .3), (.3, .5), (.5, .7), (.7, .9), (.9, 1.01)]:
            m = (conf >= lo) & (conf < hi)
            if m.sum():
                print(f"    [{lo:.1f},{min(hi, 1):.1f}) acc {ok[m].mean():.3f} n={m.sum()}")
    for key in ("supplier_key", "item_key"):
        if lc.get(key) and lc[key] in lab.columns:
            gold = j[lc[key] + "_gold"] if lc[key] + "_gold" in j.columns else j[lc[key]]
            pred = j[key]
            print(f"  {key} (all labelled rows):", cluster_scores(pred, gold))
            nb = gold != ""
            print(f"  {key} (golden non-blank only):", cluster_scores(pred[nb], gold[nb]))


if __name__ == "__main__":
    main()
