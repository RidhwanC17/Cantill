"""Two-system record matching: count every real purchase once.

Primary = system of record (e.g. ERP goods receipts, net values). Secondary = second system (e.g. AP tool,
gross values, OCR text, reformatted references). A secondary record that corresponds to a primary record is
excluded as DUPLICATE; secondary records with no counterpart are real spend found only in that system.

Stages (each only sees secondary records the previous stages left unmatched):
  1. po_amount             same PO reference + equal net amount; one-to-one assignment by text/qty/PO-item score
  2. po_text_unitprice     same PO + same item text + same unit price but different quantity: a partial or
                           combined invoice for receipts that are already counted (many-to-one allowed)
  3. supplier_amount_text  supplier-similar + equal net amount + similar text (PO missing or unusable)
  4. po_sum_of_lines       same PO, secondary amount equals the sum of 2..4 unmatched primary lines
  5. secondary_copy        leftover identical copies of one secondary line (an invoice exported twice)
"""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from rapidfuzz import fuzz

from .parsing import ocr_fold
from .spend import DUPLICATE, _field


def _compact(s: str) -> str:
    return s.replace(" ", "")


def _text_sim(a: str, b: str) -> float:
    if not a or not b:
        return 50.0            # missing text is neutral, never decisive
    r = float(fuzz.ratio(a, b))
    short, long_ = (a, b) if len(a) <= len(b) else (b, a)
    if len(short) >= 8 and len(short) < 0.8 * len(long_):
        # one side may be a truncated or partial rendering of the other (e.g. material text + service text)
        r = max(r, float(fuzz.partial_ratio(short, long_)) - 2.0)
    return r


def _ok(a: float, b: float, tol_abs: float, tol_rel: float) -> bool:
    return abs(a - b) <= max(tol_abs, tol_rel * max(abs(a), abs(b)))


class _Arr:
    """Positional numpy views of the columns used in the inner loops."""

    def __init__(self, df: pd.DataFrame):
        self.idx = df.index.values
        self.po = df["po"].values
        self.po_item = df["po_item"].values
        self.text = np.array([ocr_fold(_compact(t)) for t in df["desc_norm"].values], dtype=object)
        self.qty = df["quantity"].values.astype(float)
        self.net = df["spend_calc"].values.astype(float)
        self.gross = df["amount_raw"].values.astype(float)
        self.blank_vat_gross = (df["amount_basis"].eq("gross") & df["vat_rate"].isna()).values
        self.sup = np.array([ocr_fold(t) for t in df["supplier_norm"].values], dtype=object)
        self.rid = df["record_id"].values

    def amounts(self, i: int) -> list[float]:
        a = [self.net[i]]
        if self.blank_vat_gross[i]:
            a.append(self.gross[i])      # blank VAT may really mean "no VAT"
        return a


def _pair_score(S: _Arr, i: int, P: _Arr, j: int) -> float:
    text = _text_sim(S.text[i], P.text[j]) / 100.0
    qs, qp = S.qty[i], P.qty[j]
    if np.isnan(qs) or np.isnan(qp):
        qty = 0.5
    else:
        qty = 1.0 if abs(qs - qp) < 1e-6 else (0.3 if abs(abs(qs) - abs(qp)) < 1e-6 else 0.0)
    a, b = S.po_item[i], P.po_item[j]
    item = 0.5 if (not a or not b) else (1.0 if a == b else 0.0)
    return 0.55 * text + 0.25 * qty + 0.20 * item


def _unit_price_rel(S: _Arr, i: int, P: _Arr, j: int) -> float:
    qs, qp = S.qty[i], P.qty[j]
    if not qs or not qp or np.isnan(qs) or np.isnan(qp):
        return np.inf
    us, up = S.net[i] / qs, P.net[j] / qp
    return abs(us - up) / max(abs(up), 1e-9)


def match_systems(rec: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """Adds columns match_of (primary record_id, or the kept copy's id) and match_stage."""
    rec = rec.copy()
    rec["match_of"] = ""
    rec["match_stage"] = ""
    comb = cfg["combine"]
    if comb.get("mode") != "two_system":
        return rec
    mc = cfg.get("matching") or {}
    tol_abs = float(mc.get("amount_tolerance_abs", 0.05))
    tol_rel = float(mc.get("amount_tolerance_rel", 0.0005))
    text_min = float(mc.get("text_similarity_min", 70))
    sup_min = float(mc.get("supplier_similarity_min", 82))
    pu_text = float(mc.get("partial_text_similarity_min", 85))
    pu_tol = float(mc.get("partial_unit_price_tolerance", 0.02))

    Pdf = rec[rec["source"] == comb["primary"]]
    Sall = rec[rec["source"] == comb["secondary"]]
    Sdf = Sall[Sall["exclusion_reason"] == ""]            # cancelled / rejected records never consume a receipt
    P, S = _Arr(Pdf), _Arr(Sdf)
    used_p: set[int] = set()
    matched: dict[int, tuple[int, str]] = {}               # S position -> (P position, stage)

    by_po: dict[str, list[int]] = {}
    for j, po in enumerate(P.po):
        if po:
            by_po.setdefault(po, []).append(j)

    # ---- stage 1: PO + amount
    pairs = []
    for i in np.flatnonzero(S.po != ""):
        for j in by_po.get(S.po[i], []):
            if any(_ok(a, P.net[j], tol_abs, tol_rel) for a in S.amounts(i)):
                pairs.append((_pair_score(S, i, P, j), i, j))
    _assign(pairs, used_p, matched, "po_amount")

    # ---- stage 2: same PO + same text + same unit price (partial / combined invoice)
    for i in np.flatnonzero(S.po != ""):
        if i in matched:
            continue
        best, best_key = None, (-1.0, 0)
        for j in by_po.get(S.po[i], []):
            ts = _text_sim(S.text[i], P.text[j])
            if ts < pu_text or _unit_price_rel(S, i, P, j) > pu_tol:
                continue
            key = (ts, j not in used_p)
            if key > best_key:
                best, best_key = j, key
        if best is not None:
            matched[i] = (best, "po_text_unitprice")
            used_p.add(best)

    # ---- stage 3: supplier + amount + text, no usable PO link
    free = np.array([j for j in range(len(P.idx)) if j not in used_p], dtype=int)
    order = np.argsort(P.net[free]) if len(free) else np.array([], dtype=int)
    p_pos, p_amt = free[order], P.net[free][order]
    pairs = []
    for i in range(len(S.idx)):
        if i in matched:
            continue
        for a in S.amounts(i):
            w = max(tol_abs, tol_rel * abs(a))
            lo, hi = np.searchsorted(p_amt, a - w), np.searchsorted(p_amt, a + w, side="right")
            for j in p_pos[lo:hi]:
                if S.sup[i] and P.sup[j] and fuzz.ratio(S.sup[i], P.sup[j]) < sup_min:
                    continue
                if _text_sim(S.text[i], P.text[j]) < text_min:
                    continue
                pairs.append((_pair_score(S, i, P, j) + 0.05, i, j))
    _assign(pairs, used_p, matched, "supplier_amount_text")

    # ---- stage 4: one secondary line settling several primary lines of the same PO
    for i in np.flatnonzero(S.po != ""):
        if i in matched:
            continue
        cands = [j for j in by_po.get(S.po[i], []) if j not in used_p]
        if len(cands) < 2:
            continue
        target, found = S.net[i], None
        if _ok(target, P.net[cands].sum(), tol_abs, tol_rel):
            found = cands
        else:
            for k in (2, 3, 4):
                if len(cands) > 14 and k > 2:
                    break
                for combo in combinations(cands[:14], k):
                    if _ok(target, P.net[list(combo)].sum(), tol_abs, tol_rel):
                        found = list(combo)
                        break
                if found:
                    break
        if found:
            used_p.update(found)
            matched[i] = (found[0], "po_sum_of_lines")

    for i, (j, stage) in matched.items():
        rec.at[S.idx[i], "match_of"] = P.rid[j]
        rec.at[S.idx[i], "match_stage"] = stage

    # ---- stage 5: leftover identical copies of one secondary line (invoice exported twice)
    dd = mc.get("dedupe_secondary_copies")
    if dd:
        _dedupe_copies(rec, Sdf, set(S.idx[list(matched)]), dd)
    return rec


def _key_frame(df: pd.DataFrame, fields: list[str]) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)
    for k in fields:
        out[k] = df[k].round(2).astype(str) if k in ("amount_raw", "net_local") else _field(df, k)
    return out.astype(str)


def _dedupe_copies(rec: pd.DataFrame, Sdf: pd.DataFrame, matched_idx: set, dd: dict) -> None:
    thr, distinct = dd.get("text_similarity", 0), dd.get("distinct_if_differs", [])
    keys = _key_frame(Sdf, dd["key"])
    key_of = dict(zip(Sdf.index, map(tuple, keys.values)))
    ordered = Sdf.sort_values("row_order").index
    kept: dict[tuple, list[int]] = {}
    for idx in ordered:
        if idx in matched_idx:
            kept.setdefault(key_of[idx], []).append(idx)    # already counted via the primary system: a witness
    for idx in ordered:
        if idx in matched_idx:
            continue
        kk, target = key_of[idx], None
        for k in kept.get(kk, []):
            if _same_line(rec, idx, k, thr, distinct):
                target = rec.at[k, "record_id"]
                break
        if target is None:
            kept.setdefault(kk, []).append(idx)
        else:
            rec.at[idx, "match_of"] = target
            rec.at[idx, "match_stage"] = "secondary_copy"


def _same_line(rec: pd.DataFrame, i: int, j: int, thr: float, distinct: list[str]) -> bool:
    if thr and _text_sim(_compact(rec.at[i, "desc_norm"]), _compact(rec.at[j, "desc_norm"])) < thr:
        return False
    for f in distinct:
        a = str(rec.at[i, f]) if f in rec.columns else ""
        b = str(rec.at[j, f]) if f in rec.columns else ""
        if a and b and a != b:
            return False
    return True


def _assign(pairs: list, used_p: set, matched: dict, stage: str) -> None:
    """Greedy one-to-one assignment, best score first."""
    pairs.sort(key=lambda t: -t[0])
    for _, i, j in pairs:
        if i in matched or j in used_p:
            continue
        matched[i] = (j, stage)
        used_p.add(j)


def apply_matches(rec: pd.DataFrame) -> pd.DataFrame:
    """Turn matches into DUPLICATE exclusions (inheriting the primary's own exclusion if it has one)."""
    rec = rec.copy()
    m = rec["match_of"] != ""
    prim_reason = rec.set_index("record_id")["exclusion_reason"]
    inherited = rec.loc[m, "match_of"].map(prim_reason).fillna("")
    rec.loc[m, "exclusion_reason"] = np.where(inherited != "", inherited, DUPLICATE)
    return rec
