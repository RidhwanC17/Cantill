"""Taxonomy-aware classification of every included line into the company's own category tree.

Works with zero labels and an unseen tree:
  1. zero-shot: character- and word-level TF-IDF similarity between the line (description, GL/context text,
     supplier name) and a pseudo-document built from each leaf's path (leaf name weighted highest).
  2. consistency: lines of the same item (and, more weakly, the same supplier) share evidence.
  3. transductive self-training: the most confident lines of each category train a linear model on the
     whole corpus (descriptions, supplier tokens, context tokens); its predictions are blended back in.
  4. optional LLM refinement (llm.py) and optional supervised memory from labelled rows, both blended as
     probabilities so every source can be wrong without breaking the tree constraint.
Predictions are always leaf paths of the tree file, so hierarchical consistency is guaranteed by construction.
"""
from __future__ import annotations

import re
from typing import Optional

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier

from .parsing import norm_text
from .taxonomy import Taxonomy

_STEM = re.compile(r"(IES|ES|S|ING|ED)$")


def stem_token(t: str) -> str:
    if len(t) > 4 and t.endswith("IES"):
        return t[:-3] + "Y"
    if len(t) > 5 and t.endswith("ING"):
        return t[:-3]
    if len(t) > 4 and t.endswith("ES") and t[-3] in "SXZH":
        return t[:-2]
    if len(t) > 3 and t.endswith("S") and not t.endswith("SS"):
        return t[:-1]
    return t


def prep(text: str) -> str:
    return " ".join(stem_token(t) for t in norm_text(text).split())


def softmax(S: np.ndarray, tau: float) -> np.ndarray:
    Z = S / tau
    Z = Z - Z.max(axis=1, keepdims=True)
    E = np.exp(Z)
    return E / E.sum(axis=1, keepdims=True)


class Signatures:
    """Unique (text, context, supplier) combinations: classification runs on these, results map back to lines."""

    def __init__(self, rec: pd.DataFrame):
        key = rec["desc_norm"] + "\x1f" + rec["ctx_norm"] + "\x1f" + rec["supplier_key"] + "\x1f" + rec["item_code"]
        self.inverse, uniq = pd.factorize(key)
        first = pd.Series(np.arange(len(rec))).groupby(self.inverse).first().values
        sub = rec.iloc[first]
        self.sub = sub.reset_index(drop=True)
        self.n = len(uniq)
        self.text = [prep(t) for t in sub["desc_norm"]]
        self.ctx = [prep(t) for t in sub["ctx_norm"]]
        self.sup_name = [prep(t) for t in sub["supplier_label"]]
        self.sup_key = sub["supplier_key"].values
        self.count = np.bincount(self.inverse, minlength=self.n).astype(float)
        self.spend = np.bincount(self.inverse, weights=rec["spend_abs"].values, minlength=self.n)
        self.item_key = rec.groupby(self.inverse)["item_key"].agg(lambda s: s.iloc[0]).values
        self.rep_text = sub["description"].values        # original text (for LLM prompts)
        self.rep_ctx = sub["context"].values
        self.rep_sup = sub["supplier_name"].values


def zero_shot(sig: Signatures, tax: Taxonomy, p: dict) -> np.ndarray:
    docs = [prep(tax.path_text(i)) for i in range(tax.n)]
    # the line is scored on its description plus (weaker) its context text; supplier names add a little
    line = [f"{t} {t}" if t else "" for t in sig.text]
    char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True, min_df=1, dtype=np.float32)
    char.fit(line + sig.ctx + docs)
    word = TfidfVectorizer(analyzer="word", token_pattern=r"[A-Z0-9]{2,}", lowercase=False, sublinear_tf=True, dtype=np.float32)
    word.fit(sig.text + sig.ctx + docs)
    out = np.zeros((sig.n, tax.n), dtype=np.float32)
    for texts, w in ((sig.text, 1.0), (sig.ctx, p["ctx_weight"]), (sig.sup_name, p["supplier_weight"])):
        if w <= 0:
            continue
        sc = (char.transform(texts) @ char.transform(docs).T).toarray()
        sw = (word.transform(texts) @ word.transform(docs).T).toarray()
        out += w * (p["char_mix"] * sc + (1 - p["char_mix"]) * sw)
    return out


def _group_mean(P: np.ndarray, groups: np.ndarray, weights: np.ndarray, max_frac: float) -> np.ndarray:
    """Weighted mean of P over groups (skip blank keys and mega-groups that are not a single item/supplier)."""
    s = pd.Series(groups)
    ok = (s != "") & s.notna()
    gsize = s.map(pd.Series(weights).groupby(s).sum())
    ok &= gsize <= max_frac * weights.sum()
    out = P.copy()
    codes, _ = pd.factorize(s[ok])
    idx = np.flatnonzero(ok.values)
    if len(idx) == 0:
        return out
    G = sparse.csr_matrix((weights[idx], (codes, idx)), shape=(codes.max() + 1, len(groups)))
    mean = (G @ P) / np.maximum(np.asarray(G.sum(1)), 1e-9)
    out[idx] = mean[codes]
    return out


def self_train(sig: Signatures, P0: np.ndarray, S: np.ndarray, tax: Taxonomy, p: dict,
               extra_lab: Optional[tuple] = None) -> np.ndarray:
    """Linear model trained on the most confident lines of every class; returns its probabilities for all."""
    small = sig.n < 200
    word = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), token_pattern=r"[A-Z0-9]{2,}", lowercase=False, sublinear_tf=True,
                           min_df=1 if small else 2, dtype=np.float32)
    char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True, min_df=1 if small else 3,
                           dtype=np.float32, max_features=200000)
    side = [f"{c} " + " ".join("SUPX" + s for s in sk.split()) for c, sk in zip(sig.ctx, sig.sup_name)]
    Xw = word.fit_transform(sig.text)
    Xc = char.fit_transform(sig.text)
    Xs = TfidfVectorizer(analyzer="word", token_pattern=r"\S+", sublinear_tf=True, min_df=1,
                         dtype=np.float32).fit_transform(side)
    X = sparse.hstack([Xw, Xc, p["side_weight"] * Xs]).tocsr()

    top = P0.argmax(1)
    srt = np.sort(P0, axis=1)
    margin = srt[:, -1] - srt[:, -2]
    sim = S.max(1)
    score = margin * (sim > np.quantile(sim, p["min_sim_quantile"]))
    sel = []
    for k in range(tax.n):
        members = np.flatnonzero((top == k) & (score > 0))
        if len(members) == 0:
            continue
        # per-class budget proportional to its size, at least a few lines
        take = max(3, int(np.ceil(p["select_frac"] * len(members))))
        order = members[np.argsort(-score[members])][:take]
        sel.append(order)
    if not sel:
        return P0
    sel = np.concatenate(sel)
    y, w = top[sel], np.sqrt(sig.count[sel])
    Xtr = X[sel]
    if extra_lab is not None:
        Xl, yl, wl = extra_lab[0](X), extra_lab[1], extra_lab[2]
        Xtr = sparse.vstack([Xtr, Xl])
        y = np.concatenate([y, yl])
        w = np.concatenate([w, wl])
    clf = SGDClassifier(loss="log_loss", alpha=p["alpha"], max_iter=40, tol=None, random_state=0)
    clf.fit(Xtr, y, sample_weight=w)
    proba = np.zeros((sig.n, tax.n), dtype=np.float32)
    proba[:, clf.classes_] = clf.predict_proba(X)
    return proba


DEFAULT_PARAMS = {
    "tau": 0.06, "char_mix": 0.5, "ctx_weight": 0.5, "supplier_weight": 0.15,
    "rounds": 3, "blend_clf": 0.5, "select_frac": 0.5, "min_sim_quantile": 0.25, "alpha": 2e-5, "side_weight": 0.6,
    "item_smooth": 0.5, "supplier_smooth": 0.15, "group_max_frac": 0.02, "supplier_max_frac": 0.2,
    "llm_weight": 0.85, "calibration_power": 1.0, "confidence_floor": 0.05,
}


def classify_local(sig: Signatures, tax: Taxonomy, cfg: dict, prior_P: Optional[np.ndarray] = None,
                   prior_w: Optional[np.ndarray] = None) -> np.ndarray:
    """Signature-level class probabilities. prior_P/prior_w carry external evidence (LLM, supervised memory)."""
    p = {**DEFAULT_PARAMS, **(cfg.get("classification") or {})}
    S = zero_shot(sig, tax, p)
    Z = softmax(S, p["tau"])
    if prior_P is None:
        prior_P, prior_w = np.zeros_like(Z), np.zeros(sig.n, dtype=np.float32)
    pw = prior_w[:, None].astype(np.float32)
    cur = pw * prior_P + (1 - pw) * Z
    for _ in range(int(p["rounds"])):
        sm = _group_mean(cur, sig.item_key, sig.count, p["group_max_frac"]) * p["item_smooth"] + cur * (1 - p["item_smooth"])
        sm = _group_mean(sm, sig.sup_key, sig.count, p["supplier_max_frac"]) * p["supplier_smooth"] + sm * (1 - p["supplier_smooth"])
        try:
            Pc = self_train(sig, sm, S, tax, p)
        except ValueError:          # degenerate corpus (empty vocabulary, single class ...): keep the zero-shot evidence
            Pc = sm
        blended = p["blend_clf"] * Pc + (1 - p["blend_clf"]) * (0.5 * Z + 0.5 * sm)
        cur = pw * prior_P + (1 - pw) * blended
        cur = cur / cur.sum(1, keepdims=True)
    return cur


def combine_priors(parts: list[tuple[np.ndarray, np.ndarray]], n: int, k: int) -> tuple[np.ndarray, np.ndarray]:
    """Merge several (P, weight[n]) evidence sources: weighted average of P, noisy-or of weights."""
    if not parts:
        return np.zeros((n, k), dtype=np.float32), np.zeros(n, dtype=np.float32)
    num = sum(w[:, None] * P for P, w in parts)
    den = sum(w for _, w in parts)
    P = num / np.maximum(den[:, None], 1e-9)
    w = 1 - np.prod([1 - w for _, w in parts], axis=0)
    return P.astype(np.float32), np.minimum(w, 0.95).astype(np.float32)


def classify_records(rec: pd.DataFrame, tax: Taxonomy, cfg: dict, memory=None, llm=None) -> pd.DataFrame:
    """rec: the lines to classify. Returns DataFrame(leaf, confidence, source) aligned to rec's rows."""
    p = {**DEFAULT_PARAMS, **(cfg.get("classification") or {})}
    sig = Signatures(rec)
    parts, src_w = [], {}
    if memory is not None:
        Pm, strength = memory.predict_proba(sig.sub)
        parts.append((Pm, strength))
        src_w["supervised"] = strength
    if llm is not None:
        Pl, have = llm.classify(list(sig.rep_text), list(sig.rep_ctx), list(sig.rep_sup), sig.spend + sig.count * 1e-3)
        wl = np.where(have, p["llm_weight"], 0.0).astype(np.float32)
        parts.append((Pl, wl))
        src_w["llm"] = wl
    prior_P, prior_w = combine_priors(parts, sig.n, tax.n)
    P = classify_local(sig, tax, cfg, prior_P, prior_w)
    leaf = P.argmax(1)
    top = P.max(1)
    srt = np.sort(P, axis=1)
    margin = top - srt[:, -2]
    conf = np.clip((0.6 * top + 0.4 * margin) ** p["calibration_power"], p["confidence_floor"], 0.99)
    source = np.where(prior_w >= 0.5, "supervised", "local")
    if "llm" in src_w:
        source = np.where(src_w["llm"] > 0, "llm", source)
    # Lines decided by the offline zero-shot model alone are right far less often than their raw score suggests
    # (measured on A with labels hidden and on B's seed labels), so their confidence is compressed accordingly.
    local = source == "local"
    conf = np.where(local, 0.05 + 0.5 * conf ** 2, conf)
    out = pd.DataFrame({"leaf": leaf[sig.inverse], "confidence": conf[sig.inverse].round(3), "source": source[sig.inverse]})
    return out
