"""Company configuration: YAML (or JSON) -> validated dict with defaults.

A new company needs a new config file, never new code. See configs/company_*.yaml for worked examples and
README.md for the field reference.
"""
from __future__ import annotations

import json
import os
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

DEFAULTS: dict[str, Any] = {
    "company": "X",
    "reporting_currency": "USD",
    "data_dir": "data",
    "default_vat": 0.15,          # applied to gross amounts when the VAT rate is blank
    "day_first": True,            # ambiguous dd/mm vs mm/dd dates
    "sources": [],
    "combine": {"mode": "single"},   # single | two_system
    "fx": None,                   # {file, currency, month, rate}  (rates are units of currency per 1 USD)
    "status": {},                 # column + include/cancelled lists (generic lexicons used when omitted)
    "exclusions": {},             # see spend.py
    "taxonomy": {},               # {file, levels: [col_l1, ...]}
    "labels": None,               # optional {file, id, levels, supplier_key, item_key}; never required
    "classification": {},         # see classify.py
    "supplier": {},
    "item": {},
    "matching": {},
}

SOURCE_DEFAULTS: dict[str, Any] = {
    "amount_basis": "net",        # net | gross
    "amount_in_reporting_currency": False,
    "record_id": {"column": None, "prefix": ""},
    "columns": {},
}


def _merge(base: dict, over: dict) -> dict:
    out = deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: str | os.PathLike, data_dir: str | None = None) -> dict:
    p = Path(path)
    with open(p, "r", encoding="utf-8") as fh:
        raw = json.load(fh) if p.suffix.lower() == ".json" else yaml.safe_load(fh)
    cfg = _merge(DEFAULTS, raw)
    cfg["sources"] = [_merge(SOURCE_DEFAULTS, s) for s in cfg["sources"]]
    if data_dir:
        cfg["data_dir"] = data_dir
    cfg["_config_path"] = str(p)
    cfg["_data_dir"] = resolve_dir(cfg["data_dir"], p)
    validate(cfg)
    return cfg


def resolve_dir(d: str, cfg_path: Path) -> Path:
    """Resolve data_dir: absolute, else relative to CWD, else relative to the repo root (config's parent's parent)."""
    dp = Path(os.path.expandvars(d)).expanduser()
    if dp.is_absolute():
        return dp
    for base in (Path.cwd(), cfg_path.resolve().parent.parent):
        if (base / dp).exists():
            return (base / dp).resolve()
    return (Path.cwd() / dp).resolve()


def validate(cfg: dict) -> None:
    if not cfg["sources"]:
        raise ValueError("config needs at least one source")
    names = [s.get("name") for s in cfg["sources"]]
    if len(set(names)) != len(names) or any(n is None for n in names):
        raise ValueError("every source needs a unique 'name'")
    for s in cfg["sources"]:
        if "file" not in s:
            raise ValueError(f"source {s['name']}: 'file' missing")
        if "amount" not in s["columns"]:
            raise ValueError(f"source {s['name']}: columns.amount missing")
    if cfg["combine"].get("mode") == "two_system":
        for k in ("primary", "secondary"):
            if cfg["combine"].get(k) not in names:
                raise ValueError(f"combine.{k} must name a source")
    if not cfg["taxonomy"].get("file"):
        raise ValueError("taxonomy.file missing")
