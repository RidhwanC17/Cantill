"""Clustering and classification metrics used for self-evaluation against the labels."""
from __future__ import annotations

import numpy as np
import pandas as pd


def _comb2(x):
    x = np.asarray(x, dtype=float)
    return x * (x - 1) / 2.0


def cluster_scores(pred: pd.Series, gold: pd.Series) -> dict:
    """Pairwise precision/recall/F1, B-cubed F1 and ARI between two labelings (same index)."""
    ct = pd.crosstab(pred.astype(str), gold.astype(str)).values.astype(float)
    n = ct.sum()
    tp = _comb2(ct).sum()
    pp = _comb2(ct.sum(1)).sum()
    gp = _comb2(ct.sum(0)).sum()
    prec = tp / pp if pp else 1.0
    rec = tp / gp if gp else 1.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    # B-cubed
    bp = (ct ** 2 / ct.sum(1, keepdims=True)).sum() / n
    br = (ct ** 2 / ct.sum(0, keepdims=True)).sum() / n
    bf = 2 * bp * br / (bp + br) if bp + br else 0.0
    exp = pp * gp / _comb2(n) if n > 1 else 0
    ari = (tp - exp) / (0.5 * (pp + gp) - exp) if (0.5 * (pp + gp) - exp) else 1.0
    return {"pair_precision": round(prec, 4), "pair_recall": round(rec, 4), "pair_f1": round(f1, 4),
            "bcubed_f1": round(bf, 4), "ari": round(ari, 4), "n_pred": int(ct.shape[0]), "n_gold": int(ct.shape[1])}
