"""Spend determination: net-of-tax amounts, currency conversion, status + non-procurement exclusions,
within-source de-duplication.

All rules are driven by generic lexicons (tax / intercompany / royalty / ...) that a config can extend,
disable or point at different columns. No category names or company names live in this module.
"""
from __future__ import annotations

import re
from typing import Iterable

import numpy as np
import pandas as pd
from rapidfuzz import fuzz

from .ingest import read_table
from .parsing import norm_text

CANCELLED, NOT_APPROVED, NON_PROC, DUPLICATE = "CANCELLED", "NOT_APPROVED", "NON_PROCUREMENT", "DUPLICATE"

# --------------------------------------------------------------------------- non-procurement lexicons
# Each rule: fields (canonical or raw__ columns) + case-insensitive regex. `max_tokens` limits a rule to short,
# accounting-style text so that a product description which merely contains the word is not excluded.
DEFAULT_RULES: list[dict] = [
    {"name": "intercompany_long", "fields": ["account_text", "doc_type", "supplier_name", "description"],
     "pattern": r"\b(inter[\s\-]?company|inter[\s\-]?co\b|intragroup|intra[\s\-]group|group\s+recharge|due (to|from) (group|affiliate))"},
    {"name": "intercompany_code", "fields": ["account_text", "doc_type", "supplier_name"],
     "pattern": r"(?<![A-Za-z0-9])(IC\d*|I/C)(?![A-Za-z0-9])"},
    {"name": "tax", "fields": ["description", "account_text"], "max_tokens": 6,
     "pattern": r"\b(taxes|tax|vat|gst|hst|iva|withholding)\b",
     "veto": r"\b(tax\s+(invoice|inv)|taxi|taxation advice|tax (consult|advis|prepar|audit))"},
    {"name": "royalty", "fields": ["description", "account_text"],
     "pattern": r"\broyalt(y|ies)\b"},
    {"name": "revenue", "fields": ["account_text", "doc_type"],
     "pattern": r"\b(revenue|sales income|customer refund)\b"},
    {"name": "financing", "fields": ["description", "account_text"], "max_tokens": 8,
     "pattern": r"\b(interest (expense|payable|charges?|paid)|bank (charges?|fees?)|loan (repayment|interest)|finance (cost|charges?)|"
                r"foreign exchange (gain|loss)|fx (gain|loss)|exchange (gain|loss)|dividends?)\b"},
    {"name": "partner_billing", "fields": ["description", "account_text", "doc_type"],
     "pattern": r"\b(partner billings?|joint venture billing|jv billing|partner recharge|cost recharge)\b"},
    {"name": "payroll", "fields": ["description", "account_text"], "max_tokens": 6,
     "pattern": r"\b(payroll|salar(y|ies)|wages|pension|provident fund|social security|paye|uif)\b"},
]

DEFAULT_CANCEL = r"cancel|void|revers|annul|delet|stornier|storno"
DEFAULT_APPROVED = {"approved", "paid", "posted", "complete", "completed", "cleared", "settled", "released"}


def _field(rec: pd.DataFrame, name: str) -> pd.Series:
    if name in rec.columns:
        return rec[name].astype(str)
    if "raw__" + name in rec.columns:
        return rec["raw__" + name].astype(str)
    return pd.Series([""] * len(rec), index=rec.index)


# --------------------------------------------------------------------------- amounts and currency

def load_fx(cfg: dict) -> dict:
    """{currency: (sorted month ordinals, rates)} with rates in units of currency per 1 USD."""
    fx = cfg.get("fx")
    if not fx:
        return {}
    t = read_table(cfg["_data_dir"] / fx["file"])
    t["_m"] = pd.to_datetime(t[fx["month"]].str[:7] + "-01", errors="coerce")
    t["_r"] = pd.to_numeric(t[fx["rate"]], errors="coerce")
    t = t.dropna(subset=["_m", "_r"])
    out = {}
    for cur, g in t.groupby(fx["currency"]):
        g = g.sort_values("_m")
        out[cur.strip().upper()] = (g["_m"].dt.year.values * 12 + g["_m"].dt.month.values - 1, g["_r"].values)
    return out


def fx_rate(fxd: dict, cur: str, ym: int) -> tuple[float, str]:
    """Rate for currency in month ordinal ym: exact month, else nearest available month."""
    if cur == "USD":
        return 1.0, "usd"
    if cur not in fxd or ym is None or np.isnan(ym):
        return np.nan, "no_fx"
    months, rates = fxd[cur]
    j = int(np.argmin(np.abs(months - ym)))
    return float(rates[j]), ("table" if months[j] == ym else "table_nearest")


def _fx_month(rec: pd.DataFrame, cfg: dict) -> pd.Series:
    """Month ordinal used for fallback FX: first plausible date in fx.date_priority."""
    fx = cfg.get("fx") or {}
    prio = fx.get("date_priority", ["date"])
    gap = fx.get("max_invoice_gap_days", 400)
    base = rec["date"]
    chosen = pd.Series(pd.NaT, index=rec.index, dtype="datetime64[ns]")
    for f in prio:
        cand = rec[f] if f in rec.columns else pd.Series(pd.NaT, index=rec.index)
        ok = cand.notna()
        if f != "date":
            ok &= base.isna() | ((cand - base).abs() <= pd.Timedelta(days=gap))
        chosen = chosen.where(chosen.notna(), cand.where(ok))
    chosen = chosen.where(chosen.notna(), base)
    return (chosen.dt.year * 12 + chosen.dt.month - 1).astype(float)


def compute_amounts(rec: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    rec = rec.copy()
    R = cfg["reporting_currency"].upper()
    default_vat = float(cfg.get("default_vat", 0.15))
    gross = rec["amount_basis"].eq("gross")
    vat = rec["vat_rate"].where(rec["vat_rate"].notna(), default_vat)
    rec["vat_used"] = np.where(gross, vat, 0.0)
    rec["net_local"] = rec["amount_raw"] / (1.0 + rec["vat_used"])

    fxd = load_fx(cfg)
    ym = _fx_month(rec, cfg)
    cur = rec["currency"].str.strip().str.upper().replace({"": R})
    spend = rec["net_local"].copy()
    flag = pd.Series("", index=rec.index)
    for i in np.flatnonzero((~rec["amount_in_reporting"].values) & (cur.values != R)):
        c, amt, row_rate = cur.iat[i], rec["net_local"].iat[i], rec["rate"].iat[i]
        if np.isnan(amt):
            continue
        if row_rate and row_rate > 0 and not np.isnan(row_rate):
            usd = amt / row_rate if c != "USD" else amt
            flag.iat[i] = "row_rate"
        else:
            r, how = fx_rate(fxd, c, ym.iat[i])
            if np.isnan(r):
                flag.iat[i] = "no_fx_assumed_reporting"
                spend.iat[i] = amt
                continue
            usd = amt / r
            flag.iat[i] = how
        if R == "USD":
            spend.iat[i] = usd
        else:  # reporting currency other than USD: pivot through USD
            rr, _ = fx_rate(fxd, R, ym.iat[i])
            spend.iat[i] = usd * rr if not np.isnan(rr) else usd
    rec["spend_calc"] = spend.fillna(0.0).round(2)
    rec["fx_flag"] = flag
    rec["date_flag"] = _date_flags(rec)
    return rec


def _date_flags(rec: pd.DataFrame) -> pd.Series:
    f = pd.Series("", index=rec.index)
    raw_present = rec["date_raw"].astype(str).str.strip().ne("")
    f[rec["date"].isna() & raw_present] = "unparseable"
    bad = rec["date"].notna() & ((rec["date"].dt.year < 1990) | (rec["date"].dt.year > 2100))
    f[bad] = "out_of_range"
    if "invoice_date" in rec and rec["invoice_date"].notna().any():
        gap = (rec["date"] - rec["invoice_date"]).dt.days
        f[(f == "") & ((gap < -30) | (gap > 730))] = "inconsistent_dates"
    return f


# --------------------------------------------------------------------------- exclusions

def status_exclusion(rec: pd.DataFrame, cfg: dict) -> pd.Series:
    st = cfg.get("status") or {}
    include = {s.lower() for s in st.get("include", DEFAULT_APPROVED)}
    cancel_re = re.compile("|".join(map(re.escape, st["cancelled"])) if st.get("cancelled") else DEFAULT_CANCEL, re.I)
    s = rec["status_raw"].astype(str).str.strip()
    reason = pd.Series("", index=rec.index)
    has = s.ne("")
    low = s.str.lower()
    reason[has & ~low.isin(include)] = NOT_APPROVED
    reason[has & s.map(lambda x: bool(cancel_re.search(x)))] = CANCELLED
    return reason


def nonprocurement_exclusion(rec: pd.DataFrame, cfg: dict) -> pd.Series:
    ex = (cfg.get("exclusions") or {}).get("nonprocurement", {}) or {}
    disabled = set(ex.get("disable", []))
    rules = [r for r in DEFAULT_RULES if r["name"] not in disabled] + list(ex.get("rules", []))
    reason = pd.Series("", index=rec.index)
    why = pd.Series("", index=rec.index)
    for r in rules:
        pat = re.compile(r["pattern"], 0 if r.get("case_sensitive") else re.I)
        veto = re.compile(r["veto"], re.I) if r.get("veto") else None
        hit = pd.Series(False, index=rec.index)
        for f in r["fields"]:
            col = _field(rec, f)
            m = col.map(lambda x: bool(pat.search(x)))
            if "max_tokens" in r:
                m &= col.map(lambda x: len(norm_text(x).split()) <= r["max_tokens"])
            if veto is not None:
                m &= ~col.map(lambda x: bool(veto.search(x)))
            hit |= m
        new = hit & reason.eq("")
        reason[new] = NON_PROC
        why[new] = r["name"]
    for pid in ex.get("supplier_ids", []):
        m = rec["supplier_id"].eq(str(pid)) & reason.eq("")
        reason[m] = NON_PROC
        why[m] = "supplier_id"
    rec["nonproc_rule"] = why
    return reason


def within_source_duplicates(rec: pd.DataFrame, cfg: dict, eligible: pd.Series) -> pd.Series:
    """Mark repeated exports of the same record inside one source as DUPLICATE (first occurrence is kept).

    config:  exclusions.duplicate_within_source:
               sources: [names]            (default: all)
               key: [fields]               exact-match key (canonical or raw__ column names)
               ignore_zero_amount: bool
               text_field / text_similarity: optional fuzzy text check inside a key group
               distinct_if_differs: [fields]   two records are *different lines* if all of these are present and differ
    """
    dcfg = (cfg.get("exclusions") or {}).get("duplicate_within_source")
    out = pd.Series("", index=rec.index)
    if not dcfg:
        return out
    srcs = dcfg.get("sources")
    mask = eligible & (rec["source"].isin(srcs) if srcs else True)
    if dcfg.get("ignore_zero_amount"):
        mask &= rec["amount_raw"].fillna(0).ne(0)
    key_cols = []
    sub = rec[mask]
    keydf = pd.DataFrame(index=sub.index)
    for k in dcfg["key"]:
        v = _field(sub, k)
        if k in ("amount_raw", "net_local"):
            v = sub[k].round(2).astype(str)
        keydf[k] = v
    keydf = keydf.astype(str)
    grp = keydf.groupby(list(keydf.columns), sort=False).ngroup()
    sizes = grp.map(grp.value_counts())
    cand = sub[sizes > 1].assign(_g=grp[sizes > 1])
    text_field = dcfg.get("text_field", "desc_norm")
    thr = dcfg.get("text_similarity", 0)
    distinct = dcfg.get("distinct_if_differs", [])
    for _, g in cand.groupby("_g"):
        g = g.sort_values("row_order")
        kept: list[int] = []
        for idx in g.index:
            dup_of = None
            for k in kept:
                if thr and fuzz.ratio(str(rec.at[idx, text_field]), str(rec.at[k, text_field])) < thr:
                    continue
                conflict = False
                for f in distinct:
                    a, b = str(_field(rec.loc[[idx]], f).iat[0]), str(_field(rec.loc[[k]], f).iat[0])
                    if a and b and a != b:
                        conflict = True
                        break
                if conflict:
                    continue
                dup_of = k
                break
            if dup_of is None:
                kept.append(idx)
            else:
                out[idx] = DUPLICATE
                rec.at[idx, "dup_of"] = rec.at[dup_of, "record_id"]
    return out


def apply_exclusions(rec: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    rec = rec.copy()
    rec["dup_of"] = ""
    st = status_exclusion(rec, cfg)
    npr = nonprocurement_exclusion(rec, cfg)
    reason = st.where(st.ne(""), npr)
    dups = within_source_duplicates(rec, cfg, eligible=reason.eq(""))
    reason = reason.where(reason.ne(""), dups)
    rec["exclusion_reason"] = reason
    return rec
