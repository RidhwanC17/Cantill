"""Ingestion: read every source file listed in the config and map it onto one canonical record table."""
from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .parsing import (extract_po, extract_po_item, invoice_core, norm_text, parse_amount, parse_date,
                      parse_vat_rate, supplier_norm)

CANON_TEXT = ["supplier_name", "supplier_id", "description", "context", "item_code", "po", "po_item",
              "invoice_number", "account_text", "doc_type", "status_raw", "currency", "uom"]


def read_table(path: Path) -> pd.DataFrame:
    """Read csv/tsv/xlsx as all-string, no NA coercion; sniff the delimiter, tolerate odd encodings."""
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        return pd.read_excel(path, dtype=str).fillna("")
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    head = text[:20000]
    try:
        sep = csv.Sniffer().sniff(head, delimiters=",;\t|").delimiter
    except csv.Error:
        sep = ","
    df = pd.read_csv(io.StringIO(text), sep=sep, dtype=str, keep_default_na=False, na_filter=False,
                     on_bad_lines="warn", engine="python" if len(sep) != 1 else "c")
    df.columns = [c.strip() for c in df.columns]
    return df


def _as_list(x) -> list:
    if x is None:
        return []
    return list(x) if isinstance(x, (list, tuple)) else [x]


def _join(df: pd.DataFrame, cols: Iterable[str], sep: str = " ") -> pd.Series:
    cols = [c for c in _as_list(cols) if c in df.columns]
    if not cols:
        return pd.Series([""] * len(df), index=df.index)
    out = df[cols[0]].astype(str).str.strip()
    for c in cols[1:]:
        out = out + sep + df[c].astype(str).str.strip()
    return out.str.replace(r"\s+", " ", regex=True).str.strip(" |")


def load_source(src: dict, data_dir: Path, cfg: dict) -> pd.DataFrame:
    files = _as_list(src["file"])
    frames = [read_table(Path(data_dir) / f) for f in files]
    raw = pd.concat(frames, ignore_index=True)
    cols = src["columns"]
    out = pd.DataFrame(index=raw.index)

    rid = src["record_id"]
    if rid.get("column") and rid["column"] in raw.columns:
        ids = raw[rid["column"]].astype(str).str.strip()
    else:
        ids = pd.Series(np.arange(1, len(raw) + 1).astype(str), index=raw.index).str.zfill(7)
    out["record_id"] = rid.get("prefix", "") + ids
    out["source"] = src["name"]
    out["row_order"] = np.arange(len(raw))

    for f in CANON_TEXT:
        sep = " | " if f in {"context", "account_text"} else " "
        out[f] = _join(raw, cols.get(f), sep)

    out["description"] = out["description"].replace({"nan": ""})
    out["amount_raw"] = parse_amount(_join(raw, cols.get("amount")))
    out["quantity"] = parse_amount(_join(raw, cols.get("quantity")))
    out["rate"] = parse_amount(_join(raw, cols.get("rate")))
    out["vat_rate"] = parse_vat_rate(_join(raw, cols.get("vat_rate")))
    dayfirst = cfg.get("day_first", True)
    out["date"] = parse_date(_join(raw, cols.get("date")), dayfirst)
    out["invoice_date"] = parse_date(_join(raw, cols.get("invoice_date")), dayfirst)
    out["date_raw"] = _join(raw, cols.get("date"))
    out["amount_basis"] = src["amount_basis"]
    out["amount_in_reporting"] = bool(src["amount_in_reporting_currency"])

    # derived keys used by matching / entity resolution
    po_src = _join(raw, cols.get("po"))
    out["po"] = po_src.map(extract_po)
    out["po_item"] = [pi or extract_po_item(p) for pi, p in zip(_join(raw, cols.get("po_item")).map(
        lambda v: str(int(float(v))) if v.replace(".", "", 1).isdigit() else v), po_src)]
    out["invoice_core"] = out["invoice_number"].map(invoice_core)
    out["supplier_norm"] = out["supplier_name"].map(supplier_norm)
    out["desc_norm"] = out["description"].map(norm_text)

    # keep raw columns for exclusion rules / debugging, prefixed to avoid clashes
    for c in raw.columns:
        out["raw__" + c] = raw[c].values
    return out


def load_all(cfg: dict) -> pd.DataFrame:
    frames = []
    for src in cfg["sources"]:
        df = load_source(src, cfg["_data_dir"], cfg)
        frames.append(df)
    rec = pd.concat(frames, ignore_index=True, sort=False)
    rec["_i"] = np.arange(len(rec))
    dup_ids = rec["record_id"].duplicated(keep=False)
    if dup_ids.any():
        # never emit duplicate record ids: disambiguate deterministically
        rec.loc[dup_ids, "record_id"] = rec.loc[dup_ids, "record_id"] + "#" + rec.loc[dup_ids].groupby(
            "record_id").cumcount().astype(str)
    return rec
