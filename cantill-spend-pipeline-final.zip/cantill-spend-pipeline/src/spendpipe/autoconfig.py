"""Infer a company config from a folder of files (headers + value profiling). Used for an unseen company.

The result is a normal YAML config written to configs/company_<tag>.yaml: reviewable, editable, and what gets
committed as the "Company C config". Nothing here knows any company's column names; it scores headers against
generic procurement vocabulary and checks that the values behave (numeric, date-like, id-like, text-like).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yaml

from .ingest import read_table
from .parsing import parse_amount, parse_date
from .taxonomy import detect_levels

TABLE_EXT = {".csv", ".tsv", ".txt", ".xlsx", ".xls", ".xlsm"}


def _tokens(h: str) -> set[str]:
    h = re.sub(r"([a-z])([A-Z])", r"\1 \2", h)
    return {t for t in re.split(r"[^a-z0-9]+", h.lower()) if t}


def _has(h: str, *words: str) -> bool:
    t = _tokens(h)
    low = h.lower()
    return any((w in t) or (len(w) > 3 and w in low) for w in words)


class Profile:
    """Cheap per-column statistics on a sample."""

    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.n = len(df)
        self.stats: dict[str, dict] = {}
        for c in df.columns:
            s = df[c].astype(str).str.strip()
            ne = s[s != ""]
            st = {"fill": len(ne) / max(self.n, 1), "uniq": ne.nunique() / max(len(ne), 1) if len(ne) else 0.0,
                  "nuniq": ne.nunique()}
            if len(ne):
                num = parse_amount(ne)
                st["num"] = float(num.notna().mean())
                st["numstd"] = float(np.nanstd(num)) if num.notna().any() else 0.0
                dt = parse_date(ne.head(500))
                st["date"] = float(dt.notna().mean())
                st["alpha"] = float(ne.str.contains(r"[A-Za-z]{3,}").mean())
                st["len"] = float(ne.str.len().mean())
                st["words"] = float(ne.str.split().str.len().mean())
                st["cur"] = float(ne.str.fullmatch(r"[A-Z]{3}").mean())
            else:
                st.update(num=0, numstd=0, date=0, alpha=0, len=0, words=0, cur=0)
            self.stats[c] = st

    def __getitem__(self, c):
        return self.stats[c]


def _best(cands: list[tuple[float, str]]) -> Optional[str]:
    cands = [c for c in cands if c[0] > 0]
    return max(cands)[1] if cands else None


def infer_columns(df: pd.DataFrame) -> dict:
    P = Profile(df)
    cols = list(df.columns)
    m: dict = {}
    used: set[str] = set()

    def pick(name, scorer, many=0):
        sc = sorted(((scorer(c), c) for c in cols if c not in used), reverse=True)
        sc = [x for x in sc if x[0] > 0]
        if not sc:
            return
        if many:
            m[name] = [c for _, c in sc[:many]]
            used.update(m[name])
        else:
            m[name] = sc[0][1]
            used.add(sc[0][1])

    # Record identifier: prefer transaction/line-level keys over entity identifiers such as vendor_id.
    # Both may be unique, so uniqueness alone is not enough to distinguish their semantics.
    def record_id_score(c):
        st = P[c]
        if st["uniq"] <= 0.999 or st["fill"] <= 0.99:
            return 0
        tokens = _tokens(c)
        entity_tokens = {"supplier", "vendor", "payee", "creditor", "seller", "customer", "account",
                         "employee", "material", "item", "product", "sku"}
        if tokens & entity_tokens:
            return 0
        score = 1.0
        if tokens & {"line", "record", "row", "transaction", "txn", "receipt", "entry", "journal", "posting"}:
            score += 6.0
        if tokens & {"id", "key", "number", "no", "ref", "reference"}:
            score += 2.0
        # A generic ID is still useful, but an unqualified numeric column is not.
        if not (tokens & {"id", "key", "number", "no", "ref", "reference"}):
            score *= 0.25
        return score
    pick("_id", record_id_score)
    # amount: numeric, amount-ish header; net preferred over gross, not unit prices/tax/qty
    def amt(c):
        s = P[c]
        if s["num"] < 0.9 or s["date"] > 0.9 or _has(c, "qty", "quantity", "rate", "unit", "price", "vat", "tax", "id", "number", "no"):
            return 0
        sc = 0
        if _has(c, "amount", "amt", "value", "total", "cost", "spend", "net", "gross", "invoice"):
            sc += 5
        if _has(c, "line", "net", "local", "usd", "zar", "eur"):
            sc += 2
        if _has(c, "gross", "incl"):
            sc -= 1
        return sc + min(s["numstd"], 1e6) / 1e6 if sc > 0 else 0
    pick("amount", amt)
    # currency
    pick("currency", lambda c: (4 if P[c]["cur"] > 0.9 and _has(c, "currency", "curr", "ccy", "cur") else (1 if P[c]["cur"] > 0.95 and P[c]["nuniq"] < 60 else 0)))
    pick("rate", lambda c: 3 if (_has(c, "rate", "fx", "exchange") and P[c]["num"] > 0.4 and not _has(c, "vat", "tax")) else 0)
    pick("vat_rate", lambda c: 3 if (_has(c, "vat", "tax", "gst") and _has(c, "rate", "pct", "percent", "%") and P[c]["num"] > 0.4) else 0)
    # dates
    def dt(c, *prefer):
        s = P[c]
        if s["date"] < 0.7 or _has(c, "due", "paid", "payment", "created", "modified", "update", "delivery"):
            return 0
        return 1 + (3 if _has(c, *prefer) else 0)
    pick("date", lambda c: dt(c, "posting", "post", "gl", "receipt", "document"))
    pick("invoice_date", lambda c: dt(c, "invoice", "inv") if _has(c, "invoice", "inv") else 0)
    # suppliers
    def supname(c):
        s = P[c]
        if not _has(c, "supplier", "vendor", "payee", "creditor", "seller") or s["alpha"] < 0.7 or s["num"] > 0.5:
            return 0
        return 3 + (2 if _has(c, "name", "captured") else 0)
    pick("supplier_name", supname)
    pick("supplier_id", lambda c: 4 if (_has(c, "supplier", "vendor", "payee", "creditor", "seller") and _has(c, "id", "no", "number", "code", "key", "num")) else 0)
    # text
    def desc(c):
        s = P[c]
        if s["alpha"] < 0.6 or s["words"] < 1.3 or _has(c, "supplier", "vendor", "name") and not _has(c, "item", "material", "product"):
            return 0
        sc = 0
        if _has(c, "description", "desc", "text", "narration", "memo", "particulars", "item", "product", "material", "service", "line"):
            sc += 5
        if _has(c, "gl", "account", "cost", "center", "centre", "category", "group", "type"):
            sc -= 3
        return sc if sc > 0 else 0
    pick("description", desc, many=2)
    pick("item_code", lambda c: 4 if (_has(c, "material", "sku", "item", "part", "product", "article") and _has(c, "number", "no", "code", "id", "num", "sku")
                                      and P[c]["words"] < 2 and P[c]["num"] < 1.01) else 0)
    pick("quantity", lambda c: 4 if (_has(c, "qty", "quantity") and P[c]["num"] > 0.8) else 0)
    pick("uom", lambda c: 2 if (_has(c, "uom", "unit") and P[c]["nuniq"] < 60 and not _has(c, "price", "cost")) else 0)
    def po_score(c):
        t = _tokens(c)
        if not ({"po"} & t or _has(c, "purchase")) and not (("order" in t) and ({"number", "no", "num", "ref", "reference"} & t)):
            return 0
        if t & {"uom", "unit", "type", "date", "status", "item", "line", "qty", "quantity", "value", "amount", "price", "currency"}:
            return 0
        return 3 + (2 if t & {"number", "no", "num", "ref", "reference", "id"} else 0)
    pick("po", po_score)
    pick("po_item", lambda c: 3 if (({"po"} & _tokens(c) or _has(c, "purchase")) and {"item", "line"} & _tokens(c)
                                    and not ({"uom", "unit", "type", "date", "status", "text", "description"} & _tokens(c))) else 0)
    pick("invoice_number", lambda c: 4 if (_has(c, "invoice", "inv") and _has(c, "number", "no", "num", "id", "ref") and not _has(c, "date")) else 0)
    status_words = re.compile(r"approv|paid|cancel|reject|hold|pend|void|posted|complet|clos|open|draft|submit|block|reversed", re.I)

    def status_score(c):
        if not _has(c, "status", "state") or _has(c, "contract", "delivery", "shipment") or P[c]["nuniq"] >= 30:
            return 0
        vals = df[c].astype(str).str.strip()
        vals = vals[vals != ""]
        return 4 if len(vals) and vals.map(lambda v: bool(status_words.search(v))).mean() >= 0.3 else 0
    pick("status_raw", status_score)
    pick("doc_type", lambda c: 3 if (_has(c, "document", "doc") and _has(c, "type", "class") and P[c]["nuniq"] < 100) else 0)
    # account / context text
    def acct(c):
        s = P[c]
        if s["nuniq"] > 0.5 * max(P.n, 1) or s["alpha"] < 0.5:
            return 0
        if _has(c, "gl", "account", "ledger", "cost", "center", "centre", "expense", "category", "commodity", "group", "type", "class"):
            return 2 + (2 if _has(c, "desc", "name", "text") else 0)
        return 0
    pick("account_text", acct, many=3)
    return m


def _find_taxonomy(files: dict[str, pd.DataFrame]) -> Optional[str]:
    best, best_s = None, 0
    for f, df in files.items():
        lv = detect_levels(list(df.columns))
        s = len(lv) * 2 + (3 if re.search(r"taxonom|categor|tree|hierarch", f, re.I) else 0) - (2 if len(df) > 5000 else 0)
        if len(lv) >= 2 and s > best_s:
            best, best_s = f, s
    return best


def build_config(folder: str, tag: Optional[str] = None, out_dir: str = "configs", reporting_currency: str = "USD") -> str:
    folder_p = Path(folder)
    names = sorted(p.name for p in folder_p.iterdir() if p.suffix.lower() in TABLE_EXT and not p.name.startswith("."))
    files = {f: read_table(folder_p / f) for f in names}
    tax_file = _find_taxonomy(files)
    label_file = next((f for f in files if re.search(r"label|golden|seed|truth", f, re.I) and f != tax_file), None)
    fx_file = next((f for f in files if re.search(r"fx|rate|exchange", f, re.I) and f not in (tax_file, label_file)), None)
    txn = [f for f in files if f not in (tax_file, label_file, fx_file)]
    if not txn:
        raise SystemExit(f"no transaction file found in {folder}")
    txn.sort(key=lambda f: -len(files[f]))

    sources = []
    for f in txn:
        m = infer_columns(files[f].head(5000))
        if "amount" not in m:
            continue
        rid = m.pop("_id", None)
        basis = "gross" if re.search(r"gross|incl", m["amount"], re.I) else "net"
        cols = {k: v for k, v in m.items()}
        src = {"name": re.sub(r"\W+", "_", Path(f).stem).strip("_").lower() or "src", "file": f,
               "record_id": {"column": rid, "prefix": (re.sub(r"\W+", "", Path(f).stem)[:3].upper() + ":") if len(txn) > 1 else ""},
               "amount_basis": basis, "columns": cols}
        ctx = [c for c in cols.get("account_text", []) if isinstance(c, str)]
        if ctx:
            src["columns"]["context"] = ctx
        sources.append(src)
    if not sources:
        raise SystemExit("could not identify an amount column")

    combine = {"mode": "single"}
    if len(sources) == 2 and all("po" in s["columns"] for s in sources):
        prim = next((s for s in sources if re.search(r"erp|receipt|gr\b|goods", s["file"], re.I)), sources[0])
        sec = sources[1] if prim is sources[0] else sources[0]
        combine = {"mode": "two_system", "primary": prim["name"], "secondary": sec["name"]}
    elif len(sources) > 2:
        sources = sources[:1]

    tax_df = files.get(tax_file) if tax_file else None
    cfg = {
        "company": tag or re.sub(r"\W+", "", folder_p.name)[-6:] or "C",
        "reporting_currency": reporting_currency,
        "data_dir": str(folder_p),
        "default_vat": 0.15 if any(s["amount_basis"] == "gross" for s in sources) else 0.0,
        "day_first": True,
        "sources": sources,
        "combine": combine,
        "taxonomy": {"file": tax_file, "levels": detect_levels(list(tax_df.columns)) if tax_df is not None else []},
    }
    if fx_file:
        fx = files[fx_file]
        P = Profile(fx)
        cur = next((c for c in fx.columns if P[c]["cur"] > 0.9), fx.columns[0])
        mon = next((c for c in fx.columns if P[c]["date"] > 0.8 or _has(c, "month", "date", "period")), fx.columns[1])
        rate = next((c for c in fx.columns if P[c]["num"] > 0.9 and c not in (cur, mon)), fx.columns[-1])
        cfg["fx"] = {"file": fx_file, "currency": cur, "month": mon, "rate": rate,
                     "date_priority": ["invoice_date", "date"], "max_invoice_gap_days": 400}
    if label_file:
        cfg["labels"] = {"file": label_file, "id": next(iter(files[label_file].columns)), "levels": cfg["taxonomy"]["levels"]}

    out = Path(out_dir) / f"company_{cfg['company']}.yaml"
    out.parent.mkdir(parents=True, exist_ok=True)
    header = ("# AUTO-GENERATED by `main.py --auto-config`. Column mapping was inferred from headers and values.\n"
              "# Review before freezing; edit freely (see README.md for every field).\n")
    out.write_text(header + yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")
    return str(out)
