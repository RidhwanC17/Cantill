"""spendpipe: config-driven spend cube pipeline (ingest, spend rules, matching, entity resolution, classification)."""
__version__ = "1.0.0"
