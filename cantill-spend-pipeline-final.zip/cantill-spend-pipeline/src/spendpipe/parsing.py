"""Robust parsers for amounts, dates, VAT rates, PO references and free text.

Everything here is vectorised over pandas Series and has no company-specific logic.
"""
from __future__ import annotations

import re
from typing import Optional

import numpy as np
import pandas as pd
from unidecode import unidecode

# ----------------------------------------------------------------------------- amounts

_NUM_CLEAN = re.compile(r"[^\d,.\-+()]")
_THOUSANDS_COMMA = re.compile(r"^-?\d{1,3}(,\d{3})+(\.\d+)?$")
_THOUSANDS_DOT = re.compile(r"^-?\d{1,3}(\.\d{3})+(,\d+)?$")


def parse_amount_str(raw: object) -> float:
    """Parse one amount string. Handles 1,234.56 / 1.234,56 / 1 234,56 / (123.45) / 123.45- / R 1,000."""
    if raw is None:
        return np.nan
    if isinstance(raw, (int, float, np.integer, np.floating)):
        return float(raw)
    s = str(raw).strip()
    if s == "" or s.lower() in {"nan", "none", "null", "-", "n/a", "na"}:
        return np.nan
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg, s = True, s[1:-1]
    if s.endswith("-") and not s.startswith("-"):
        neg, s = True, s[:-1]
    s = _NUM_CLEAN.sub("", s.replace("\u00a0", " ").replace(" ", ""))
    s = s.replace("(", "").replace(")", "").replace("+", "")
    if s in {"", "-", ".", ","}:
        return np.nan
    if "," in s and "." in s:
        # whichever separator occurs last is the decimal separator
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        if _THOUSANDS_COMMA.match(s):
            s = s.replace(",", "")
        elif re.match(r"^-?\d+,\d{1,2}$", s):
            s = s.replace(",", ".")
        else:
            s = s.replace(",", "")
    elif s.count(".") > 1 and _THOUSANDS_DOT.match(s):
        s = s.replace(".", "")
    try:
        v = float(s)
    except ValueError:
        return np.nan
    return -v if neg else v


def parse_amount(series: pd.Series) -> pd.Series:
    return series.map(parse_amount_str).astype(float)


def parse_vat_rate(series: pd.Series) -> pd.Series:
    """'15' / '0.15' / '15%' -> 0.15 ; blank -> NaN (caller applies the default)."""
    def one(x):
        v = parse_amount_str(str(x).replace("%", ""))
        if np.isnan(v):
            return np.nan
        return v / 100.0 if v >= 1.0 else v
    return series.map(one).astype(float)


# ----------------------------------------------------------------------------- dates

_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

_RE_ISO = re.compile(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T\s].*)?$")
_RE_COMPACT = re.compile(r"^(\d{4})(\d{2})(\d{2})$")
_RE_NUMERIC = re.compile(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2}|\d{4})(?:[T\s].*)?$")
_RE_DMON = re.compile(r"^(\d{1,2})[-/. ]([A-Za-z]{3,9})[-/. ,]*(\d{2}|\d{4})$")
_RE_MONDY = re.compile(r"^([A-Za-z]{3,9})[-/. ]+(\d{1,2})(?:st|nd|rd|th)?[-/. ,]+(\d{2}|\d{4})$")
_RE_SERIAL = re.compile(r"^\d{5}(\.\d+)?$")


def _year(y: str) -> int:
    n = int(y)
    if len(y) == 2:
        return 2000 + n if n < 70 else 1900 + n
    return n


def parse_date_str(raw: object, day_first: bool = True) -> Optional[pd.Timestamp]:
    """Return a Timestamp or None. Never guesses on impossible dates."""
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "" or s.lower() in {"nan", "nat", "none", "null", "0", "00000000", "0000-00-00"}:
        return None
    try:
        m = _RE_ISO.match(s)
        if m:
            return pd.Timestamp(int(m[1]), int(m[2]), int(m[3]))
        m = _RE_COMPACT.match(s)
        if m:
            return pd.Timestamp(int(m[1]), int(m[2]), int(m[3]))
        m = _RE_DMON.match(s)
        if m and m[2][:3].lower() in _MONTHS:
            return pd.Timestamp(_year(m[3]), _MONTHS[m[2][:3].lower()], int(m[1]))
        m = _RE_MONDY.match(s)
        if m and m[1][:3].lower() in _MONTHS:
            return pd.Timestamp(_year(m[3]), _MONTHS[m[1][:3].lower()], int(m[2]))
        m = _RE_NUMERIC.match(s)
        if m:
            a, b, y = int(m[1]), int(m[2]), _year(m[3])
            first, second = (a, b) if day_first else (b, a)
            # first=day, second=month; swap if impossible
            if second > 12 and first <= 12:
                first, second = second, first
            return pd.Timestamp(y, second, first)
        if _RE_SERIAL.match(s):
            serial = float(s)
            if 20000 < serial < 80000:  # Excel serial
                return pd.Timestamp("1899-12-30") + pd.Timedelta(days=serial)
    except (ValueError, OverflowError):
        return None
    return None


def parse_date(series: pd.Series, day_first: bool = True) -> pd.Series:
    out = series.map(lambda x: parse_date_str(x, day_first))
    return pd.to_datetime(out, errors="coerce")


# ----------------------------------------------------------------------------- text

_PUNCT = re.compile(r"[^A-Z0-9]+")
_WS = re.compile(r"\s+")
_LEGAL = {
    "PTY", "LTD", "LIMITED", "CC", "INC", "LLC", "LLP", "GMBH", "SA", "AG", "BV", "NV", "SARL", "SRL", "SPA",
    "CO", "CORP", "CORPORATION", "COMPANY", "PLC", "SAS", "AB", "AS", "OY", "KG", "OHG", "UG", "SL", "SDN", "BHD",
    "PVT", "PRIVATE", "THE", "AND", "OF", "PT", "TBK", "LP", "LLLP", "ULC",
}


def norm_text(x: object) -> str:
    """Upper-case ASCII, punctuation to spaces, single spaced."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return ""
    s = unidecode(str(x)).upper()
    return _WS.sub(" ", _PUNCT.sub(" ", s)).strip()


def norm_series(s: pd.Series) -> pd.Series:
    return s.map(norm_text)


_OCR_FOLD = str.maketrans({"0": "O", "1": "I", "5": "S", "8": "B", "2": "Z"})


def ocr_fold(s: str) -> str:
    """Comparison-only fold of common OCR digit/letter confusions (T00LS == TOOLS). Never used for display keys."""
    return s.translate(_OCR_FOLD)


def supplier_norm(x: object) -> str:
    """Supplier name key: normalised, legal suffixes dropped, spaces removed.

    Removing *all* spaces collapses OCR/typing breaks ("PRAH AVEN" == "PRAHAVEN").
    """
    toks = [t for t in norm_text(x).split() if t not in _LEGAL]
    return "".join(toks)


_PO_RE = re.compile(r"(?<!\d)(\d{8,12})(?!\d)")


def extract_po(x: object) -> str:
    """Pull the PO digit run out of references such as '4510085877/10.0', 'PO#4510055507', 'PO 4510...'."""
    if x is None:
        return ""
    m = _PO_RE.search(str(x))
    return m.group(1) if m else ""


def extract_po_item(x: object) -> str:
    """'4510085877/10.0' -> '10'."""
    if x is None:
        return ""
    m = re.search(r"\d{8,12}\s*[/\-]\s*(\d{1,5})(?:\.0+)?\b", str(x))
    return m.group(1).lstrip("0") or "0" if m else ""


def invoice_core(x: object) -> str:
    """Invoice number with prefixes/format noise removed: 'INV/2023/759857' -> '759857', 'TAX INV 590375' -> '590375'."""
    s = norm_text(x)
    runs = re.findall(r"\d{4,}", s)
    if runs:
        return max(runs, key=len)
    return s.replace(" ", "")


def to_float(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")
