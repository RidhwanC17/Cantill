"""End-to-end pipeline: ingest -> amounts -> exclusions -> matching -> entities -> classification -> output."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from .classify import classify_records
from .config import load_config
from .entities import inherit_from_primary, resolve_items, resolve_suppliers
from .ingest import load_all
from .llm import LLMClassifier, llm_enabled
from .matching import apply_matches, match_systems
from .parsing import norm_text
from .spend import apply_exclusions, compute_amounts
from .supervised import SupervisedMemory, load_labels
from .taxonomy import load_taxonomy

OUT_COLUMNS = ["record_id", "include", "exclusion_reason", "supplier_key", "item_key", "spend",
               "l1", "l2", "l3", "l4", "confidence"]

EXCL_CONFIDENCE = {"CANCELLED": 0.97, "NOT_APPROVED": 0.97, "NON_PROCUREMENT": 0.85, "DUPLICATE": 0.9}


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def prepare(cfg: dict) -> pd.DataFrame:
    """Everything up to (and including) entity resolution; no classification."""
    log(f"company {cfg['company']}: ingesting from {cfg['_data_dir']}")
    rec = load_all(cfg)
    log(f"  {len(rec):,} records from {rec['source'].nunique()} source(s)")
    rec = compute_amounts(rec, cfg)
    rec = apply_exclusions(rec, cfg)
    rec = match_systems(rec, cfg)
    rec = apply_matches(rec)
    rec = resolve_suppliers(rec, cfg)
    rec = resolve_items(rec, cfg)
    rec = inherit_from_primary(rec)
    rec["ctx_norm"] = rec["context"].map(norm_text)
    rec["spend_abs"] = rec["spend_calc"].abs()
    log("  exclusions: " + str(rec["exclusion_reason"].replace("", "INCLUDED").value_counts().to_dict()))
    return rec


def build_memory(cfg: dict, tax, current_ids: set, use_labels: bool) -> Optional[SupervisedMemory]:
    """Train the optional supervised memory on labelled rows of the same company (never the rows being scored)."""
    lc = cfg.get("labels")
    if not (use_labels and lc):
        return None
    ldir = Path(lc.get("dir", cfg["_data_dir"]))
    if not ldir.is_absolute():
        for base in (Path.cwd(), Path(cfg["_config_path"]).resolve().parent.parent):
            if (base / ldir).exists():
                ldir = (base / ldir).resolve()
                break
    lcfg = {**cfg, "_data_dir": ldir}
    if not (ldir / lc["file"]).exists():
        log(f"  labels file {ldir / lc['file']} not found: running with zero labels")
        return None
    labels = load_labels(lcfg, tax)
    if labels is None or labels.empty:
        return None
    if Path(ldir).resolve() == Path(cfg["_data_dir"]).resolve():
        labels = labels[~labels["record_id"].isin(current_ids)]      # never train on the rows being scored (dev runs)
    if len(labels) < 200:
        log(f"  only {len(labels)} usable labelled rows outside the scored data: running with zero labels")
        return None
    train = load_all(lcfg)
    train = compute_amounts(train, lcfg)
    train = resolve_suppliers(train, lcfg)
    train["ctx_norm"] = train["context"].map(norm_text)
    train = train.merge(labels, on="record_id", how="inner")
    log(f"  supervised memory: {len(train):,} labelled rows from {ldir}")
    return SupervisedMemory(tax).fit(train, train["_y"].values)


def run(config_path: str, out_dir: str = "outputs", name: str = "ridhwan", tag: Optional[str] = None,
        data_dir: Optional[str] = None, labels: str = "auto", llm: str = "auto", no_classify: bool = False,
        source_files: Optional[dict] = None, limit: Optional[int] = None) -> pd.DataFrame:
    t0 = time.time()
    cfg = load_config(config_path, data_dir)
    for s in cfg["sources"]:
        if source_files and s["name"] in source_files:
            s["file"] = source_files[s["name"]]
    rec = prepare(cfg)
    if limit:
        rec = rec.head(limit)
    tax = load_taxonomy(cfg)
    log(f"  taxonomy: {tax.n} leaves, depth {tax.depth}")

    inc_mask = rec["exclusion_reason"].eq("")
    inc = rec[inc_mask].reset_index(drop=True)
    cls = pd.DataFrame(index=rec.index, columns=["leaf", "confidence", "source"])
    if not no_classify and len(inc):
        memory = build_memory(cfg, tax, set(rec["record_id"]), use_labels=(labels != "off"))
        client = None
        if llm_enabled(llm):
            lc = cfg.get("classification", {}) or {}
            client = LLMClassifier(tax, model=lc.get("llm_model"), batch_size=int(lc.get("llm_batch_size", 40)),
                                   workers=int(lc.get("llm_workers", 6)), budget_seconds=float(lc.get("llm_budget_seconds", 2400)),
                                   domain_hint=lc.get("domain_hint", ""))
            log(f"  LLM layer on ({client.model})")
        else:
            log("  LLM layer off (set ANTHROPIC_API_KEY to enable): local classifier only")
        log(f"  classifying {len(inc):,} included lines")
        res = classify_records(inc, tax, cfg, memory=memory, llm=client)
        res.index = rec.index[inc_mask]
        cls.loc[res.index, ["leaf", "confidence", "source"]] = res[["leaf", "confidence", "source"]].values
    out = write_output(rec, cls, tax, cfg, out_dir, name, tag)
    log(f"done in {time.time() - t0:.0f}s")
    return out


def write_output(rec: pd.DataFrame, cls: pd.DataFrame, tax, cfg: dict, out_dir: str, name: str, tag: Optional[str]) -> pd.DataFrame:
    width = max(4, tax.depth)
    inc = rec["exclusion_reason"].eq("")
    out = pd.DataFrame({
        "record_id": rec["record_id"].values,
        "include": inc.astype(int).values,
        "exclusion_reason": rec["exclusion_reason"].values,
        "supplier_key": rec["supplier_key"].values,
        "item_key": rec["item_key"].values,
        "spend": np.where(inc, rec["spend_calc"], 0.0).round(2),
    })
    for k in range(width):
        out[f"l{k + 1}"] = ""
    conf = np.array([EXCL_CONFIDENCE.get(r, 0.9) for r in rec["exclusion_reason"]], dtype=float)
    for pos in np.flatnonzero(inc.values & cls["leaf"].notna().values):
        path = tax.padded(int(cls["leaf"].iat[pos]), width)
        for k in range(width):
            out.iat[pos, 6 + k] = path[k]
        conf[pos] = float(cls["confidence"].iat[pos])
    out["confidence"] = np.round(conf, 3)
    cols = OUT_COLUMNS[:6] + [f"l{k + 1}" for k in range(width)] + ["confidence"]
    out = out[cols]
    if out_dir:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        tag = tag or cfg["company"]
        path = Path(out_dir) / f"{name}__{tag}.csv"
        out.to_csv(path, index=False)
        log(f"wrote {path} ({len(out):,} rows)")
        diag = rec[["record_id", "source", "exclusion_reason", "nonproc_rule", "match_of", "match_stage", "dup_of",
                    "fx_flag", "date_flag", "vat_used", "net_local"]].copy()
        diag["class_source"] = cls["source"].values
        diag.to_csv(Path(out_dir) / f"diagnostics_{tag}.csv", index=False)
    return out
