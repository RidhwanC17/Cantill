"""Optional supervised memory built from labelled rows of the *same* company (e.g. A's golden labels, B's seed
labels). Labels are local, confidential and never committed; with no labels file this module is simply skipped,
and the tool must (and does) work without it.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier

from .ingest import read_table
from .taxonomy import Taxonomy


def load_labels(cfg: dict, tax: Taxonomy) -> Optional[pd.DataFrame]:
    lc = cfg.get("labels")
    if not lc:
        return None
    path = Path(cfg["_data_dir"]) / lc["file"]
    if not path.exists():
        return None
    df = read_table(path)
    levels = lc.get("levels") or tax.levels
    idx = {l: i for i, l in enumerate(tax.leaves)}
    paths = [tuple(v for v in row if v != "") for row in df[levels].itertuples(index=False)]
    df = df.assign(_y=[idx.get(p, -1) for p in paths])
    df = df[df["_y"] >= 0]
    out = df[[lc["id"], "_y"]].rename(columns={lc["id"]: "record_id"})
    return out.drop_duplicates("record_id")


class SupervisedMemory:
    """TF-IDF + linear model on labelled rows, plus exact item-code memory."""

    def __init__(self, tax: Taxonomy):
        self.tax = tax

    @staticmethod
    def _side(rec: pd.DataFrame) -> list[str]:
        out = []
        for ctx, sup, code in zip(rec["ctx_norm"], rec["supplier_label"], rec["item_code"]):
            toks = ["SUPX" + t for t in str(sup).upper().split()] + (["CODEX" + str(code)] if code else [])
            out.append(f"{ctx} " + " ".join(toks))
        return out

    def fit(self, rec: pd.DataFrame, y: np.ndarray) -> "SupervisedMemory":
        self.word = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), token_pattern=r"[A-Z0-9]{2,}", lowercase=False, sublinear_tf=True,
                                    min_df=1, dtype=np.float32)
        self.char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True, min_df=2, dtype=np.float32,
                                    max_features=250000)
        self.side = TfidfVectorizer(analyzer="word", token_pattern=r"\S+", sublinear_tf=True, dtype=np.float32)
        X = self._X(rec, fit=True)
        self.clf = SGDClassifier(loss="log_loss", alpha=1e-5, max_iter=40, tol=None, random_state=0)
        self.clf.fit(X, y)
        codes = pd.DataFrame({"code": rec["item_code"].values, "y": y})
        codes = codes[codes["code"] != ""]
        self.code_y = codes.groupby("code")["y"].agg(lambda s: s.value_counts().index[0]).to_dict()
        self.code_purity = codes.groupby("code")["y"].agg(lambda s: s.value_counts(normalize=True).iloc[0]).to_dict()
        return self

    def _X(self, rec: pd.DataFrame, fit: bool = False):
        t = rec["desc_norm"].tolist()
        s = self._side(rec)
        if fit:
            return sparse.hstack([self.word.fit_transform(t), self.char.fit_transform(t), 0.6 * self.side.fit_transform(s)]).tocsr()
        return sparse.hstack([self.word.transform(t), self.char.transform(t), 0.6 * self.side.transform(s)]).tocsr()

    def predict_proba(self, rec: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """(P [n x K], strength [n]) where strength in [0,1] says how much to trust the memory for each row."""
        K = self.tax.n
        P = np.zeros((len(rec), K), dtype=np.float32)
        P[:, self.clf.classes_] = self.clf.predict_proba(self._X(rec))
        strength = np.full(len(rec), 0.55, dtype=np.float32)
        for i, c in enumerate(rec["item_code"].values):
            if c and c in self.code_y and self.code_purity[c] >= 0.99:
                P[i] = 0.02 / K
                P[i, self.code_y[c]] = 0.98
                P[i] /= P[i].sum()
                strength[i] = 0.9
        return P, strength
