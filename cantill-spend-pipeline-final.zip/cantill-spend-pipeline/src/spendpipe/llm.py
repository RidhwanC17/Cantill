"""Optional LLM layer (Anthropic API). Used only when ANTHROPIC_API_KEY is set; the pipeline runs without it.

Why: an unseen tree with abbreviated, noisy, multilingual purchase text needs world knowledge that no offline model
we can ship has. The LLM sees the whole tree as a numbered list of leaf paths (read from the tree file at run
time) and picks one leaf per line, so its output is always a valid path and never a free-text category.

Safety properties:
  * every failure (no key, network, bad JSON, timeout, budget) degrades to the local classifier for those lines;
  * results are cached on disk keyed by (model, tree, line signature) so reruns are free and deterministic;
  * a wall-clock budget bounds the run, highest-spend lines are sent first;
  * temperature 0.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import numpy as np

from .taxonomy import Taxonomy

DEFAULT_MODEL = "claude-haiku-5-5"

SYSTEM_PROMPT = (
    "You are a senior procurement category manager. You classify purchase-order and invoice lines into a "
    "company's own category tree. Lines are often abbreviated, truncated, OCR-noisy, upper-case, or written in "
    "any language; use the supplier name and the account/context text as additional evidence. "
    "Choose exactly ONE leaf from the numbered list for every line, even when unsure (then give a low confidence). "
    "Answer with JSON only."
)


def llm_enabled(cfg_mode: str = "auto") -> bool:
    if cfg_mode == "off":
        return False
    have_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
    if cfg_mode == "on" and not have_key:
        print("[llm] mode=on but ANTHROPIC_API_KEY is not set: falling back to local classifier")
    return have_key


class LLMClassifier:
    def __init__(self, tax: Taxonomy, model: Optional[str] = None, batch_size: int = 40, workers: int = 6,
                 budget_seconds: float = 2400.0, cache_dir: str = ".cache", client=None, verbose: bool = True,
                 domain_hint: str = ""):
        self.tax = tax
        self.model = model or os.environ.get("CANTILL_LLM_MODEL") or DEFAULT_MODEL
        self.batch_size = batch_size
        self.workers = workers
        self.budget = budget_seconds
        self.verbose = verbose
        self.domain_hint = domain_hint
        self._client = client
        self._lock = threading.Lock()
        tree_id = hashlib.md5("\n".join(" > ".join(l) for l in tax.leaves).encode()).hexdigest()[:10]
        Path(cache_dir).mkdir(parents=True, exist_ok=True)
        self.cache_path = Path(cache_dir) / f"llm_{self.model}_{tree_id}.jsonl"
        self.cache: dict[str, dict] = {}
        if self.cache_path.exists():
            for line in self.cache_path.read_text(encoding="utf-8").splitlines():
                try:
                    d = json.loads(line)
                    self.cache[d["k"]] = d
                except Exception:
                    pass
        self.tree_list = "\n".join(f"{i + 1}. {' > '.join(l)}" for i, l in enumerate(tax.leaves))
        self.stats = {"calls": 0, "failed_batches": 0, "cache_hits": 0, "classified": 0}
        self.fatal = False                      # auth / unknown-model errors: stop calling, fall back to local

    # ---------------------------------------------------------------------------------- client
    @property
    def client(self):
        if self._client is None:
            import anthropic
            self._client = anthropic.Anthropic(max_retries=4, timeout=120.0)
        return self._client

    @staticmethod
    def sig_key(desc: str, ctx: str, sup: str) -> str:
        return hashlib.md5(f"{desc}\x1f{ctx}\x1f{sup}".encode("utf-8")).hexdigest()

    # ---------------------------------------------------------------------------------- prompt / parsing
    def build_prompt(self, items: list[dict]) -> str:
        hint = f"Business context: {self.domain_hint}\n" if self.domain_hint else ""
        lines = []
        for it in items:
            parts = [f'"desc": {json.dumps(it["desc"][:200], ensure_ascii=False)}']
            if it["ctx"]:
                parts.append(f'"account": {json.dumps(it["ctx"][:120], ensure_ascii=False)}')
            if it["sup"]:
                parts.append(f'"supplier": {json.dumps(it["sup"][:80], ensure_ascii=False)}')
            lines.append("{" + f'"i": {it["i"]}, ' + ", ".join(parts) + "}")
        return (
            f"{hint}Category tree (choose by number):\n{self.tree_list}\n\n"
            "Classify each line below. Reply with a JSON array, one object per line, exactly in the form "
            '{"i": <line i>, "c": <leaf number>, "p": <confidence 0-1>, "alt": <second-best leaf number or null>}.\n\n'
            "Lines:\n" + "\n".join(lines)
        )

    def parse(self, text: str, expected: set[int]) -> dict[int, dict]:
        m = re.search(r"\[.*\]", text, re.S)
        if not m:
            return {}
        try:
            arr = json.loads(m.group(0))
        except json.JSONDecodeError:
            arr = []
            for obj in re.findall(r"\{[^{}]*\}", m.group(0)):
                try:
                    arr.append(json.loads(obj))
                except json.JSONDecodeError:
                    pass
        out = {}
        K = self.tax.n
        for o in arr:
            try:
                i, c = int(o["i"]), int(o["c"])
            except (KeyError, TypeError, ValueError):
                continue
            if i not in expected or not (1 <= c <= K):
                continue
            p = o.get("p", 0.6)
            try:
                p = float(p)
            except (TypeError, ValueError):
                p = 0.6
            alt = o.get("alt")
            alt = int(alt) if isinstance(alt, (int, float)) and 1 <= int(alt) <= K and int(alt) != c else None
            out[i] = {"c": c - 1, "p": min(max(p, 0.05), 0.99), "alt": None if alt is None else alt - 1}
        return out

    # ---------------------------------------------------------------------------------- one batch
    def _run_batch(self, items: list[dict]) -> dict[int, dict]:
        if self.fatal:
            return {}
        prompt = self.build_prompt(items)
        expected = {it["i"] for it in items}
        for attempt in range(3):
            try:
                resp = self.client.messages.create(
                    model=self.model, max_tokens=4096, temperature=0, system=SYSTEM_PROMPT,
                    messages=[{"role": "user", "content": prompt}])
                text = "".join(getattr(b, "text", "") for b in resp.content)
                with self._lock:
                    self.stats["calls"] += 1
                res = self.parse(text, expected)
                if len(res) >= 0.8 * len(items):
                    return res
            except Exception as e:  # network, auth, overloaded ... never fatal for the pipeline
                if type(e).__name__ in {"AuthenticationError", "PermissionDeniedError", "NotFoundError", "BadRequestError"}:
                    if not self.fatal and self.verbose:
                        print(f"[llm] {type(e).__name__}: {str(e)[:160]} -> LLM layer disabled, using local classifier "
                              f"(check ANTHROPIC_API_KEY / CANTILL_LLM_MODEL)")
                    self.fatal = True
                    return {}
                if self.verbose and attempt == 2:
                    print(f"[llm] batch failed: {type(e).__name__}: {str(e)[:120]}")
                time.sleep(1.5 * (attempt + 1))
        with self._lock:
            self.stats["failed_batches"] += 1
        return {}

    # ---------------------------------------------------------------------------------- public API
    def classify(self, descs: list[str], ctxs: list[str], sups: list[str], priority: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Returns (P [n x K] float32, have [n] bool). Rows with have=False carry no LLM information."""
        n, K = len(descs), self.tax.n
        P = np.zeros((n, K), dtype=np.float32)
        have = np.zeros(n, dtype=bool)
        todo = []
        for i in np.argsort(-priority):
            k = self.sig_key(descs[i], ctxs[i], sups[i])
            if k in self.cache:
                self._fill(P, have, i, self.cache[k])
                self.stats["cache_hits"] += 1
            else:
                todo.append(int(i))
        if todo:
            t0 = time.time()
            batches = [todo[a:a + self.batch_size] for a in range(0, len(todo), self.batch_size)]
            if self.verbose:
                print(f"[llm] {len(todo)} signatures in {len(batches)} batches ({self.model}); cache hits {self.stats['cache_hits']}")

            def work(batch):
                if time.time() - t0 > self.budget:
                    return batch, {}
                items = [{"i": j, "desc": descs[j], "ctx": ctxs[j], "sup": sups[j]} for j in batch]
                return batch, self._run_batch(items)

            with ThreadPoolExecutor(max_workers=self.workers) as ex, open(self.cache_path, "a", encoding="utf-8") as fh:
                futs = [ex.submit(work, b) for b in batches]
                for f in as_completed(futs):
                    batch, res = f.result()
                    for j, r in res.items():
                        self._fill(P, have, j, r)
                        rec = {"k": self.sig_key(descs[j], ctxs[j], sups[j]), **r}
                        self.cache[rec["k"]] = rec
                        fh.write(json.dumps(rec) + "\n")
                    fh.flush()
        self.stats["classified"] = int(have.sum())
        if self.verbose:
            print(f"[llm] {have.sum()}/{n} signatures classified by LLM; stats {self.stats}")
        return P, have

    def _fill(self, P: np.ndarray, have: np.ndarray, i: int, r: dict) -> None:
        K = P.shape[1]
        p = float(r["p"])
        base = 0.02 / K
        P[i, :] = base
        P[i, r["c"]] = max(p, 0.3)
        if r.get("alt") is not None:
            P[i, r["alt"]] = max((1 - p) * 0.6, base)
        P[i] /= P[i].sum()
        have[i] = True
