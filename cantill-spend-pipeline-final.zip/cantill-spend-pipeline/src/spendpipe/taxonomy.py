"""Taxonomy: read the company's category tree from a file at run time. No category name appears in code."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .ingest import read_table

_LEVEL_RE = re.compile(r"^(?:category[_\s]*)?(?:l|level)[_\s]*(\d+)$", re.I)


@dataclass
class Taxonomy:
    levels: list[str]                       # column names in the tree file, shallow -> deep
    leaves: list[tuple[str, ...]]           # every distinct root-to-leaf path (names exactly as in the file)
    depth: int = 0
    names: dict = field(default_factory=dict)

    @property
    def n(self) -> int:
        return len(self.leaves)

    def path_text(self, i: int, weights=(3, 2, 1)) -> str:
        """Pseudo-document for leaf i: leaf name repeated most, ancestors less."""
        path = self.leaves[i]
        parts = []
        for depth_from_leaf, name in enumerate(reversed(path)):
            w = weights[min(depth_from_leaf, len(weights) - 1)]
            parts.extend([name] * w)
        return " ".join(parts)

    def label(self, i: int) -> str:
        return " > ".join(self.leaves[i])

    def padded(self, i: int, width: int) -> list[str]:
        p = list(self.leaves[i])
        return p + [""] * (width - len(p))


def detect_levels(columns: list[str]) -> list[str]:
    found = []
    for c in columns:
        m = _LEVEL_RE.match(c.strip())
        if m:
            found.append((int(m.group(1)), c))
    return [c for _, c in sorted(found)]


def load_taxonomy(cfg: dict) -> Taxonomy:
    tcfg = cfg["taxonomy"]
    df = read_table(Path(cfg["_data_dir"]) / tcfg["file"])
    levels = tcfg.get("levels") or detect_levels(list(df.columns))
    if not levels:
        # fallback: treat all columns, in order, as levels
        levels = list(df.columns)
    seen, leaves = set(), []
    for row in df[levels].itertuples(index=False):
        path = tuple(str(v).strip() for v in row)
        # cut at first blank: depth of this branch
        cut = [p for p in path]
        while cut and cut[-1] == "":
            cut.pop()
        if not cut or "" in cut:
            continue
        t = tuple(cut)
        if t not in seen:
            seen.add(t)
            leaves.append(t)
    # a path that is a strict prefix of another path is an internal node, not a selectable leaf
    prefixes = {l[:k] for l in leaves for k in range(1, len(l))}
    leaves = [l for l in leaves if l not in prefixes]
    return Taxonomy(levels=levels, leaves=leaves, depth=max(len(l) for l in leaves))
