"""Entity resolution: one supplier_key per real supplier, one item_key per real item.

Suppliers: union-find over shared vendor IDs and equal normalised names, then a conservative fuzzy merge of
near-identical names (typos, OCR spacing, legal-suffix variants).
Items: material code is the strongest identity; codes that carry identical, specific text can be merged;
lines without a code are clustered on their text; lines matched across systems inherit the primary's keys.
"""
from __future__ import annotations

import hashlib
from collections import Counter

import numpy as np
import pandas as pd
from rapidfuzz import fuzz, process

from .parsing import ocr_fold


class UnionFind:
    def __init__(self, n: int):
        self.p = np.arange(n)

    def find(self, x: int) -> int:
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[max(ra, rb)] = min(ra, rb)


def _short(prefix: str, label: str) -> str:
    return f"{prefix}-{hashlib.md5(label.encode('utf-8')).hexdigest()[:7]}"


def _fuzzy_components(strings: list[str], threshold: float, min_len: int = 5, chunk: int = 2000) -> list[tuple[int, int]]:
    """Index pairs (i<j) of strings whose ratio >= threshold (both at least min_len long)."""
    idx = [i for i, s in enumerate(strings) if len(s) >= min_len]
    sub = [strings[i] for i in idx]
    pairs = []
    for a in range(0, len(sub), chunk):
        m = process.cdist(sub[a:a + chunk], sub, scorer=fuzz.ratio, score_cutoff=threshold, dtype=np.uint8, workers=1)
        ii, jj = np.nonzero(m)
        for x, y in zip(ii, jj):
            x += a
            if x < y:
                pairs.append((idx[x], idx[y]))
    return pairs


# ------------------------------------------------------------------------------------------ suppliers

def resolve_suppliers(rec: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    sc = cfg.get("supplier") or {}
    thr = float(sc.get("fuzzy_threshold", 92))
    rec = rec.copy()
    n = len(rec)
    uf = UnionFind(n)
    first_seen: dict[tuple, int] = {}
    for i, (sid, nm) in enumerate(zip(rec["supplier_id"].values, rec["supplier_norm"].values)):
        for tok in ((("id", sid),) if sid else ()) + ((("nm", nm),) if nm else ()):
            if tok in first_seen:
                uf.union(first_seen[tok], i)
            else:
                first_seen[tok] = i
    # fuzzy merge across distinct names
    names = sorted({nm for nm in rec["supplier_norm"].values if nm})
    folded = [ocr_fold(n_) for n_ in names]
    for a, b in _fuzzy_components(folded, thr, min_len=int(sc.get("fuzzy_min_len", 6))):
        uf.union(first_seen[("nm", names[a])], first_seen[("nm", names[b])])
    root = np.array([uf.find(i) for i in range(n)])
    rec["_sup_root"] = root

    # optional: names that never carry a vendor ID are un-mastered long-tail suppliers -> one bucket
    gm = sc.get("group_unmastered")
    if gm:
        has_id = rec.groupby("_sup_root")["supplier_id"].transform(lambda s: (s != "").any())
        tail = ~has_id & rec["supplier_norm"].ne("")
        rec.loc[tail, "_sup_root"] = -1

    label = {}
    raw = rec["supplier_name"].where(rec["supplier_name"].ne(""), rec["supplier_id"])
    for r, grp in raw.groupby(rec["_sup_root"]):
        label[r] = "UNMASTERED" if r == -1 else (Counter(grp).most_common(1)[0][0] or "UNKNOWN")
    rec["supplier_key"] = rec["_sup_root"].map(lambda r: _short("SUP", str(label[r]) + ("" if r == -1 else str(r))))
    rec["supplier_label"] = rec["_sup_root"].map(label)
    no_ident = rec["supplier_name"].eq("") & rec["supplier_id"].eq("")
    rec.loc[no_ident, "supplier_key"] = _short_many("SUP-NOID", rec.loc[no_ident, "record_id"])
    return rec.drop(columns=["_sup_root"])


def _short_many(prefix: str, ids: pd.Series) -> pd.Series:
    return ids.map(lambda x: _short(prefix, str(x)))


# ------------------------------------------------------------------------------------------ items

def resolve_items(rec: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    ic = cfg.get("item") or {}
    thr = float(ic.get("text_threshold", 92))
    merge_codes = bool(ic.get("merge_codes_by_text", True))
    no_code = ic.get("no_code", "text_cluster")             # text_cluster | blank
    min_tokens = int(ic.get("min_tokens_for_text_merge", 6))
    rec = rec.copy()
    n = len(rec)
    uf = UnionFind(n)
    first_code: dict[str, int] = {}
    for i, c in enumerate(rec["item_code"].values):
        if c:
            if c in first_code:
                uf.union(first_code[c], i)
            else:
                first_code[c] = i

    text = rec["desc_norm"].map(lambda s: s.replace(" ", ""))
    ntok = rec["desc_norm"].map(lambda s: len(s.split()))
    first_text: dict[str, int] = {}
    # exact-text identity (specific descriptions only) merges codes and code-less lines
    for i, (t, k, c) in enumerate(zip(text.values, ntok.values, rec["item_code"].values)):
        if not t or k < min_tokens:
            continue
        if c and not merge_codes:
            continue
        if t in first_text:
            j = first_text[t]
            if rec["item_code"].iat[j] and c and not merge_codes:
                continue
            uf.union(j, i)
        else:
            first_text[t] = i

    # fuzzy text clusters for code-less lines (OCR noise, abbreviations), within the same supplier cluster
    if no_code == "text_cluster":
        nocode = np.flatnonzero((rec["item_code"].values == "") & (ntok.values >= min_tokens))
        by_sup: dict[str, list[int]] = {}
        for i in nocode:
            by_sup.setdefault(rec["supplier_key"].iat[i], []).append(i)
        for _, members in by_sup.items():
            uniq = sorted({text.iat[i] for i in members})
            if len(uniq) < 2:
                continue
            rep = {}
            for i in members:
                rep.setdefault(text.iat[i], i)
            for a, b in _fuzzy_components(uniq, thr, min_len=8):
                uf.union(rep[uniq[a]], rep[uniq[b]])

    root = np.array([uf.find(i) for i in range(n)])
    rec["_item_root"] = root
    # label each cluster by its most common code, else most common text
    lab = {}
    for r, grp in rec.groupby("_item_root"):
        codes = [c for c in grp["item_code"] if c]
        lab[r] = Counter(codes).most_common(1)[0][0] if codes else Counter(grp["desc_norm"]).most_common(1)[0][0]
    rec["item_key"] = rec["_item_root"].map(lambda r: _short("ITM", str(lab[r])))
    blank = rec["item_code"].eq("") & rec["desc_norm"].eq("")
    rec.loc[blank, "item_key"] = _short_many("ITM-NOTEXT", rec.loc[blank, "record_id"])
    ca = ic.get("catch_all")
    if ca:   # un-mastered lines (e.g. free-text / catalogue purchases) share one generic item
        from .spend import _field
        hit = _field(rec, ca["field"]).str.strip().str.lower().isin([str(v).lower() for v in ca["values"]])
        rec.loc[hit & (rec["item_code"].ne("") | (no_code != "blank")), "item_key"] = _short("ITM", ca.get("label", "OTHER"))
    if no_code == "blank":
        rec.loc[rec["item_code"].eq(""), "item_key"] = ""
    return rec.drop(columns=["_item_root"])


def inherit_from_primary(rec: pd.DataFrame) -> pd.DataFrame:
    """Secondary records matched to a primary record share its supplier and item identity."""
    rec = rec.copy()
    m = rec["match_of"].ne("") & rec["match_stage"].ne("secondary_copy")
    by_id = rec.set_index("record_id")
    for col in ("supplier_key", "item_key"):
        rec.loc[m, col] = rec.loc[m, "match_of"].map(by_id[col])
    by_id = rec.set_index("record_id")        # refresh: copies may point at a record that just inherited
    c = rec["match_stage"].eq("secondary_copy")
    for col in ("supplier_key", "item_key"):
        rec.loc[c, col] = rec.loc[c, "match_of"].map(by_id[col]).fillna(rec.loc[c, col])
    return rec
