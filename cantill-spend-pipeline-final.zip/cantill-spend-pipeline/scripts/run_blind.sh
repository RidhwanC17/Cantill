#!/usr/bin/env bash
# Blind-test runner. Usage: bash scripts/run_blind.sh <new_A_dir> <new_B_dir> <company_C_dir> [yourname]
# Runs the FROZEN code on fresh data and copies the three CSVs + the Company C config into submission/.
set -euo pipefail
A_DIR="${1:?new A folder}"; B_DIR="${2:?new B folder}"; C_DIR="${3:?company C folder}"; NAME="${4:-ridhwan}"
cd "$(dirname "$0")/.."
python main.py --config configs/company_A.yaml --data-dir "$A_DIR" --tag A2 --name "$NAME" --out outputs
python main.py --config configs/company_B.yaml --data-dir "$B_DIR" --tag B2 --name "$NAME" --out outputs
python main.py --auto-config "$C_DIR" --tag C --name "$NAME" --out outputs
mkdir -p submission
cp "outputs/${NAME}__A2.csv" "outputs/${NAME}__B2.csv" "outputs/${NAME}__C.csv" submission/
cp configs/company_C.yaml submission/company_C.yaml
echo "Done. Review submission/, then: git add submission && git commit -m 'blind test outputs' && git push"
