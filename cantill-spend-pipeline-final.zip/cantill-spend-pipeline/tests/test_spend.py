import numpy as np
import pandas as pd

from spendpipe.config import load_config
from spendpipe.ingest import load_all
from spendpipe.spend import apply_exclusions, compute_amounts, nonprocurement_exclusion


def test_gross_to_net_and_status(toy_company):
    cfg = load_config(toy_company)
    rec = apply_exclusions(compute_amounts(load_all(cfg), cfg), cfg)
    t = rec[rec.source == "tool"].set_index("record_id")
    assert t.loc["TOOL:T1", "spend_calc"] == 1000.0          # 1150 / 1.15
    assert t.loc["TOOL:T2", "spend_calc"] == 500.0           # blank VAT -> 15%
    assert t.loc["TOOL:T6", "exclusion_reason"] == "CANCELLED"


def test_fx_row_rate_table_and_usd(tmp_path):
    d = tmp_path / "fx"
    d.mkdir()
    pd.DataFrame({"category_l1": ["A"], "category_l2": ["B"]}).to_csv(d / "tax.csv", index=False)
    pd.DataFrame({"id": ["1", "2", "3", "4"], "amt": ["100", "100", "100", "100"], "cur": ["EUR", "EUR", "USD", "ZZZ"],
                  "rate": ["0.5", "", "0.5", ""], "dt": ["2024-02-10"] * 4, "txt": ["x"] * 4}).to_csv(d / "t.csv", index=False)
    pd.DataFrame({"currency": ["EUR", "EUR"], "month": ["2024-01", "2024-03"], "units_per_usd": ["0.8", "0.9"]}).to_csv(d / "fx.csv", index=False)
    (d / "c.yaml").write_text(f"""
company: FX
reporting_currency: USD
data_dir: {d}
sources:
  - {{name: s, file: t.csv, record_id: {{column: id}}, columns: {{amount: amt, currency: cur, rate: rate, date: dt, description: txt}}}}
fx: {{file: fx.csv, currency: currency, month: month, rate: units_per_usd}}
taxonomy: {{file: tax.csv, levels: [category_l1, category_l2]}}
""")
    cfg = load_config(d / "c.yaml")
    rec = compute_amounts(load_all(cfg), cfg).set_index("record_id")
    assert rec.loc["0000001" if "0000001" in rec.index else rec.index[0], "spend_calc"] == 200.0      # 100 / 0.5 (row rate)
    assert rec.iloc[1]["spend_calc"] in (125.0, 111.11)   # no row rate: nearest month in table (Jan=0.8 or Mar=0.9)
    assert rec.iloc[2]["spend_calc"] == 100.0             # USD already USD, rate ignored
    assert rec.iloc[3]["fx_flag"] == "no_fx_assumed_reporting"


def test_nonprocurement_rules_and_no_false_positives():
    rec = pd.DataFrame({
        "description": ["State & Local Taxes -", "HEAVY DUTY HOSE", "Sales Tax Expense -", "Tax invoice adjustment note x y z", "bearing"],
        "account_text": ["IC Payables", "Trade Payables", "Trade Payables", "Trade Payables", "I/C Payable"],
        "doc_type": [""] * 5, "supplier_name": [""] * 5,
    })
    r = nonprocurement_exclusion(rec, {})
    assert list(r) == ["NON_PROCUREMENT", "", "NON_PROCUREMENT", "", "NON_PROCUREMENT"]
