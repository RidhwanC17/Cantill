import numpy as np
import pandas as pd

from spendpipe.parsing import (extract_po, extract_po_item, invoice_core, parse_amount_str, parse_date_str,
                               parse_vat_rate, supplier_norm)


def test_amounts():
    assert parse_amount_str("5,266.63") == 5266.63
    assert parse_amount_str("1.234,56") == 1234.56
    assert parse_amount_str("1 234,56") == 1234.56
    assert parse_amount_str("(123.45)") == -123.45
    assert parse_amount_str("123.45-") == -123.45
    assert parse_amount_str("R 1,000") == 1000.0
    assert parse_amount_str("12,5") == 12.5
    assert np.isnan(parse_amount_str(""))
    assert np.isnan(parse_amount_str("n/a"))


def test_dates():
    assert parse_date_str("2024-03-05") == pd.Timestamp(2024, 3, 5)
    assert parse_date_str("05/03/2024", day_first=True) == pd.Timestamp(2024, 3, 5)
    assert parse_date_str("05/03/2024", day_first=False) == pd.Timestamp(2024, 5, 3)
    assert parse_date_str("25/03/2024", day_first=False) == pd.Timestamp(2024, 3, 25)   # impossible month -> swapped
    assert parse_date_str("5-Mar-24") == pd.Timestamp(2024, 3, 5)
    assert parse_date_str("March 5, 2024") == pd.Timestamp(2024, 3, 5)
    assert parse_date_str("20240305") == pd.Timestamp(2024, 3, 5)
    assert parse_date_str("31/02/2024") is None          # impossible dates are flagged, never guessed
    assert parse_date_str("garbage") is None and parse_date_str("") is None


def test_vat():
    s = parse_vat_rate(pd.Series(["15", "0.15", "15%", "", "0"]))
    assert list(s[:3]) == [0.15, 0.15, 0.15] and np.isnan(s[3]) and s[4] == 0.0


def test_references():
    assert extract_po("PO#4510055507") == "4510055507"
    assert extract_po("4510085877/10.0") == "4510085877"
    assert extract_po_item("4510085877/10.0") == "10"
    assert extract_po("") == ""
    assert invoice_core("INV/2023/759857") == "759857"
    assert invoice_core("TAX INV 590375") == "590375"


def test_supplier_norm_collapses_ocr_and_legal_suffix():
    assert supplier_norm("PRAH AVEN (PTY) LTD") == supplier_norm("PRAHAVEN") == supplier_norm("Prahaven Pty Ltd")
