import json
import re
from pathlib import Path

import numpy as np

from spendpipe.config import load_config
from spendpipe.llm import LLMClassifier
from spendpipe.pipeline import prepare
from spendpipe.classify import classify_records
from spendpipe.taxonomy import load_taxonomy


def test_zero_shot_returns_valid_leaves_and_confidence(toy_company):
    cfg = load_config(toy_company)
    rec = prepare(cfg)
    inc = rec[rec.exclusion_reason == ""].reset_index(drop=True)
    tax = load_taxonomy(cfg)
    out = classify_records(inc, tax, cfg)
    assert out.leaf.between(0, tax.n - 1).all() and out.confidence.between(0, 1).all()
    by = dict(zip(inc.record_id, out.leaf))
    assert tax.leaves[by["ERP:E2"]] == ("Fruit", "Pome", "Apples")             # 'red apples 5kg box'
    assert tax.leaves[by["ERP:E3"]] == ("Tools", "Hand Tools", "Hammers")      # 'claw hammer'


class FakeClient:
    """Mimics anthropic.Anthropic().messages.create; answers 'tool'-like lines with leaf n."""
    def __init__(self, fail=False, garbage=False):
        self.fail, self.garbage, self.calls = fail, garbage, 0
        self.messages = self

    def create(self, **kw):
        self.calls += 1
        if self.fail:
            raise RuntimeError("boom")
        prompt = kw["messages"][0]["content"]
        if self.garbage:
            text = "I cannot do that"
        else:
            out = [{"i": int(i), "c": 3, "p": 0.9, "alt": 1} for i in re.findall(r'\{"i": (\d+),', prompt)]
            text = "```json\n" + json.dumps(out) + "\n```"
        return type("R", (), {"content": [type("B", (), {"text": text})()]})()


def test_llm_prompt_contains_tree_and_classifies(toy_company, tmp_path):
    cfg = load_config(toy_company)
    tax = load_taxonomy(cfg)
    fc = FakeClient()
    llm = LLMClassifier(tax, client=fc, cache_dir=str(tmp_path / "c"), batch_size=3, workers=1, verbose=False)
    P, have = llm.classify(["a", "b", "c", "d"], ["", "", "", ""], ["", "", "", ""], np.ones(4))
    assert have.all() and P.argmax(1).tolist() == [2, 2, 2, 2] and fc.calls == 2
    assert "Fruit > Citrus > Oranges" in llm.build_prompt([{"i": 0, "desc": "x", "ctx": "", "sup": ""}])
    # second run is served from the disk cache
    fc2 = FakeClient()
    llm2 = LLMClassifier(tax, client=fc2, cache_dir=str(tmp_path / "c"), verbose=False)
    llm2.classify(["a", "b", "c", "d"], ["", "", "", ""], ["", "", "", ""], np.ones(4))
    assert fc2.calls == 0


def test_llm_failure_degrades_to_local(toy_company, tmp_path):
    cfg = load_config(toy_company)
    tax = load_taxonomy(cfg)
    for fc in (FakeClient(fail=True), FakeClient(garbage=True)):
        llm = LLMClassifier(tax, client=fc, cache_dir=str(tmp_path / f"c{id(fc)}"), verbose=False)
        P, have = llm.classify(["a"], [""], [""], np.ones(1))
        assert not have.any()
    rec = prepare(cfg)
    inc = rec[rec.exclusion_reason == ""].reset_index(drop=True)
    out = classify_records(inc, tax, cfg, llm=LLMClassifier(tax, client=FakeClient(fail=True), cache_dir=str(tmp_path / "z"), verbose=False))
    assert len(out) == len(inc)


def test_no_category_names_in_source():
    """The tree is a run-time input: none of the three companies' category names may appear in code."""
    src = "\n".join(p.read_text() for p in Path(__file__).resolve().parents[1].glob("src/spendpipe/*.py")).lower()
    for banned in ["mining explosives", "roof bolts", "can body stock", "aluminium", "freight", "continuous miners"]:
        assert banned not in src, banned
