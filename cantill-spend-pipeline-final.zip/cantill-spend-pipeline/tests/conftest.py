import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


@pytest.fixture()
def toy_company(tmp_path):
    """A tiny two-system company with a made-up tree, written to disk (no confidential data in tests)."""
    d = tmp_path / "toy"
    d.mkdir()
    pd.DataFrame({
        "category_l1": ["Fruit", "Fruit", "Tools", "Tools"],
        "category_l2": ["Citrus", "Pome", "Hand Tools", "Power Tools"],
        "category_l3": ["Oranges", "Apples", "Hammers", "Drills"],
    }).to_csv(d / "taxonomy.csv", index=False)
    erp = pd.DataFrame({
        "line_id": [f"E{i}" for i in range(1, 9)],
        "po_number": ["4500000001", "4500000002", "4500000003", "4500000004", "4500000005", "4500000006", "4500000007", "4500000008"],
        "po_item": ["10", "10", "10", "10", "10", "10", "10", "10"],
        "supplier_name": ["ACME FRUIT (PTY) LTD", "ACME FRUIT PTY LTD", "BOLT TOOLS CC", "BOLT TOOLS", "ACME FRUIT (PTY) LTD", "BOLT TOOLS CC", "ZED SUPPLY", "ZED SUPPLY"],
        "vendor_id": ["V1", "V1", "V2", "", "V1", "V2", "", ""],
        "material_number": ["M1", "M2", "M3", "M3", "M1", "M4", "", ""],
        "text": ["fresh oranges 10kg box", "red apples 5kg box", "claw hammer 500g", "claw hammer 500g", "fresh oranges 10kg box", "cordless drill 18v", "oranges bulk delivery", "apples bulk delivery"],
        "value": ["1000.00", "500.00", "250.00", "250.00", "1200.00", "900.00", "300.00", "310.00"],
        "qty": ["10", "5", "2", "2", "12", "1", "3", "3"],
        "posting_date": ["2024-01-05", "05/01/2024", "2024-01-07", "2024-01-08", "2024-02-01", "2024-02-03", "2024-02-05", "2024-02-06"],
    })
    erp.to_csv(d / "erp.csv", index=False)
    tool = pd.DataFrame({
        "rec": ["T1", "T2", "T3", "T4", "T5", "T6", "T7"],
        "po_ref": ["PO#4500000001", "4500000002/10.0", "", "4500000003", "4500000003", "4500000009", "4500000005"],
        "inv": ["INV/2024/1001", "INV/2024/1002", "INV/2024/1003", "INV/2024/1004", "INV/2024/1004", "INV/2024/1005", "INV/2024/1006"],
        "supplier": ["ACME FRUIT", "ACME  FRUIT", "BOLT T00LS", "BOLT TOOLS", "BOLT TOOLS", "NEW VENDOR", "ACME FRUIT"],
        "line": ["fresh oranges 10kg bx", "red apples 5kg box", "cordless dril 18v", "claw hammer 500g", "claw hammer 500g", "garden spade", "fresh oranges 10kg box"],
        "gross": ["1,150.00", "575.00", "1,035.00", "287.50", "287.50", "115.00", "690.00"],
        "vat": ["15", "", "0.15", "15%", "15%", "15", "15"],
        "qty": ["10", "5", "1", "2", "2", "1", "6"],
        "status": ["Approved", "Paid", "Approved", "Approved", "Approved", "Cancelled", "Approved"],
    })
    tool.to_csv(d / "tool.csv", index=False)
    cfg = f"""
company: TOY
reporting_currency: ZAR
data_dir: {d}
default_vat: 0.15
sources:
  - name: erp
    file: erp.csv
    record_id: {{column: line_id, prefix: "ERP:"}}
    amount_in_reporting_currency: true
    columns: {{amount: value, date: posting_date, supplier_name: supplier_name, supplier_id: vendor_id, description: text,
              item_code: material_number, quantity: qty, po: po_number, po_item: po_item}}
  - name: tool
    file: tool.csv
    record_id: {{column: rec, prefix: "TOOL:"}}
    amount_basis: gross
    amount_in_reporting_currency: true
    columns: {{amount: gross, supplier_name: supplier, description: line, quantity: qty, po: po_ref,
              invoice_number: inv, vat_rate: vat, status_raw: status}}
combine: {{mode: two_system, primary: erp, secondary: tool}}
status: {{include: [approved, paid]}}
matching:
  dedupe_secondary_copies: {{key: [invoice_core, supplier_norm, amount_raw], text_similarity: 80, distinct_if_differs: [po_item]}}
taxonomy: {{file: taxonomy.csv, levels: [category_l1, category_l2, category_l3]}}
"""
    p = d / "toy.yaml"
    p.write_text(cfg)
    return p
