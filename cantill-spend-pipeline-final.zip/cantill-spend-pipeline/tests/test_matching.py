from spendpipe.config import load_config
from spendpipe.ingest import load_all
from spendpipe.matching import apply_matches, match_systems
from spendpipe.spend import apply_exclusions, compute_amounts


def run(toy_company):
    cfg = load_config(toy_company)
    rec = apply_exclusions(compute_amounts(load_all(cfg), cfg), cfg)
    rec = apply_matches(match_systems(rec, cfg))
    return rec.set_index("record_id")


def test_po_amount_and_noisy_formats(toy_company):
    r = run(toy_company)
    assert r.loc["TOOL:T1", "match_of"] == "ERP:E1" and r.loc["TOOL:T1", "exclusion_reason"] == "DUPLICATE"
    assert r.loc["TOOL:T2", "match_of"] == "ERP:E2"           # PO in "4500000002/10.0" form


def test_po_missing_falls_back_to_supplier_amount_text(toy_company):
    r = run(toy_company)
    assert r.loc["TOOL:T3", "match_of"] == "ERP:E6" and r.loc["TOOL:T3", "match_stage"] == "supplier_amount_text"


def test_exported_twice_counts_once_and_cancelled_never_matches(toy_company):
    r = run(toy_company)
    assert r.loc["TOOL:T4", "match_of"] == "ERP:E3"           # first copy settles the receipt
    assert r.loc["TOOL:T5", "exclusion_reason"] == "DUPLICATE"  # second copy is a duplicate, not new spend
    assert r.loc["TOOL:T6", "exclusion_reason"] == "CANCELLED" and r.loc["TOOL:T6", "match_of"] == ""


def test_partial_invoice_same_unit_price_is_not_new_spend(toy_company):
    r = run(toy_company)
    # T7: 6 oranges at the same unit price on a PO already received for 12 -> already counted via the ERP
    assert r.loc["TOOL:T7", "exclusion_reason"] == "DUPLICATE"
    assert r.loc["TOOL:T7", "match_stage"] == "po_text_unitprice"
