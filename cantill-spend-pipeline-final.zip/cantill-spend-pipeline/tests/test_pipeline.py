import pandas as pd

from spendpipe.pipeline import run

COLS = ["record_id", "include", "exclusion_reason", "supplier_key", "item_key", "spend", "l1", "l2", "l3", "l4", "confidence"]


def test_end_to_end_schema_and_rules(toy_company, tmp_path):
    out = run(str(toy_company), out_dir=str(tmp_path / "o"), name="x", tag="T", llm="off", labels="off")
    assert list(out.columns) == COLS
    assert len(out) == 15 and out.record_id.is_unique                      # one row per input record
    inc, exc = out[out.include == 1], out[out.include == 0]
    assert (exc.spend == 0).all() and (exc[["l1", "l2", "l3", "l4"]] == "").all().all()
    assert set(exc.exclusion_reason) <= {"CANCELLED", "NOT_APPROVED", "NON_PROCUREMENT", "DUPLICATE"}
    assert (inc.exclusion_reason == "").all() and inc.l1.ne("").all() and inc.confidence.between(0, 1).all()
    assert set(inc.l1) <= {"Fruit", "Tools"}                                # names exactly as in the tree file
    assert (tmp_path / "o" / "x__T.csv").exists()
    # an ERP line counted once: T1 is its duplicate
    assert out.set_index("record_id").loc["TOOL:T1", "exclusion_reason"] == "DUPLICATE"


def test_autoconfig_on_toy_runs(toy_company, tmp_path):
    from spendpipe.autoconfig import build_config
    p = build_config(str(toy_company.parent), tag="TOYAUTO", out_dir=str(tmp_path / "cfg"))
    out = run(p, out_dir=str(tmp_path / "o2"), name="y", tag="TA", llm="off", labels="off")
    assert len(out) > 0 and out.include.isin([0, 1]).all()
