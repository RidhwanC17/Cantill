import copy

from spendpipe.config import load_config
from spendpipe.entities import resolve_items, resolve_suppliers
from spendpipe.ingest import load_all
from spendpipe.spend import apply_exclusions, compute_amounts


def prep(toy_company):
    cfg = load_config(toy_company)
    rec = apply_exclusions(compute_amounts(load_all(cfg), cfg), cfg)
    return cfg, rec


def test_supplier_variants_and_vendor_ids_merge(toy_company):
    cfg, rec = prep(toy_company)
    r = resolve_suppliers(rec, cfg).set_index("record_id")
    assert r.loc["ERP:E1", "supplier_key"] == r.loc["ERP:E2", "supplier_key"] == r.loc["TOOL:T1", "supplier_key"] == r.loc["TOOL:T2", "supplier_key"]
    # "BOLT TOOLS CC" (vendor V2), "BOLT TOOLS" (no id) and the OCR'd "BOLT T00LS" are one real supplier
    assert r.loc["ERP:E3", "supplier_key"] == r.loc["ERP:E4", "supplier_key"] == r.loc["ERP:E6", "supplier_key"]
    assert r.loc["ERP:E1", "supplier_key"] != r.loc["ERP:E3", "supplier_key"]


def test_items_by_code_and_text(toy_company):
    cfg, rec = prep(toy_company)
    r = resolve_items(resolve_suppliers(rec, cfg), cfg).set_index("record_id")
    assert r.loc["ERP:E1", "item_key"] == r.loc["ERP:E5", "item_key"]          # same material code
    assert r.loc["ERP:E1", "item_key"] != r.loc["ERP:E2", "item_key"]
    c = copy.deepcopy(cfg)
    c["item"] = {"no_code": "blank"}
    assert resolve_items(resolve_suppliers(rec, c), c).set_index("record_id").loc["ERP:E7", "item_key"] == ""
