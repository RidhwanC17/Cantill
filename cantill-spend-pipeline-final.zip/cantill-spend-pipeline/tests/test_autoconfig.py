import pandas as pd

from spendpipe.autoconfig import infer_columns


def test_record_id_prefers_line_identifier_over_unique_vendor_identifier():
    df = pd.DataFrame({
        "line_id": [f"LINE-{i:03d}" for i in range(20)],
        "vendor_id": [f"VENDOR-{i:03d}" for i in range(20)],
        "supplier_name": [f"Supplier {i}" for i in range(20)],
        "line_description": ["industrial cleaning service" for _ in range(20)],
        "net_amount": [100 + i for i in range(20)],
    })

    inferred = infer_columns(df)

    assert inferred["_id"] == "line_id"
    assert inferred["supplier_id"] == "vendor_id"


def test_record_id_does_not_select_supplier_id_when_no_line_id_exists():
    df = pd.DataFrame({
        "vendor_id": [f"VENDOR-{i:03d}" for i in range(20)],
        "supplier_name": [f"Supplier {i}" for i in range(20)],
        "description": ["industrial cleaning service" for _ in range(20)],
        "amount": [100 + i for i in range(20)],
    })

    inferred = infer_columns(df)

    assert inferred.get("_id") != "vendor_id"
