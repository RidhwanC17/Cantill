import numpy as np
import pandas as pd

from spendpipe.classify import Signatures, zero_shot
from spendpipe.taxonomy import Taxonomy
from spendpipe.classify import DEFAULT_PARAMS


def test_zero_shot_handles_alphabetic_only_descriptions_and_taxonomy():
    # Regression test: uppercase token_pattern must not be lowercased by sklearn
    # before tokenisation, otherwise alphabetic-only corpora have an empty vocabulary.
    rec = pd.DataFrame({
        "desc_norm": ["INDUSTRIAL CLEANING SERVICE", "OFFICE FURNITURE REPAIR"],
        "ctx_norm": ["FACILITIES MANAGEMENT", "WORKPLACE SUPPORT"],
        "supplier_key": ["SUPPLIER ONE", "SUPPLIER TWO"],
        "item_code": ["", ""],
        "spend_abs": [120.0, 240.0],
        "item_key": ["ITEM ONE", "ITEM TWO"],
        "description": ["Industrial cleaning service", "Office furniture repair"],
        "context": ["Facilities management", "Workplace support"],
        "supplier_label": ["Supplier One", "Supplier Two"],
        "supplier_name": ["Supplier One", "Supplier Two"],
    })
    sig = Signatures(rec)
    tax = Taxonomy(
        levels=["category_l1", "category_l2"],
        leaves=[("Facilities", "Cleaning"), ("Workplace", "Furniture")],
        depth=2,
    )

    scores = zero_shot(sig, tax, DEFAULT_PARAMS)

    assert scores.shape == (2, 2)
    assert np.isfinite(scores).all()
    assert (scores >= 0).all()
