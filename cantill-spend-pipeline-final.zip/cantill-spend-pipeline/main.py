#!/usr/bin/env python3
"""One command, any company:

    python main.py --config configs/company_A.yaml --name yourname
    python main.py --config configs/company_B.yaml --data-dir path/to/new_B_files --tag B2
    python main.py --auto-config path/to/company_C_folder --name yourname          # unseen company, no config yet

Outputs <out>/<name>__<tag>.csv in the template schema. See README.md.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from spendpipe.pipeline import run  # noqa: E402


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", help="company YAML (configs/company_A.yaml, ...)")
    ap.add_argument("--auto-config", metavar="DIR", help="infer a config for an unseen company's folder, write it to "
                    "configs/company_<tag>.yaml, then run it")
    ap.add_argument("--data-dir", help="folder holding the company's files (overrides the config)")
    ap.add_argument("--out", default="outputs", help="output folder (default: outputs)")
    ap.add_argument("--name", default="ridhwan", help="file-name prefix: <name>__<tag>.csv")
    ap.add_argument("--tag", help="file-name tag (default: the company code in the config, e.g. A, B2, C)")
    ap.add_argument("--labels", choices=["auto", "off"], default="auto",
                    help="auto: use the config's labels as supervised memory when they exist; off: zero labels")
    ap.add_argument("--llm", choices=["auto", "off", "on"], default="auto",
                    help="auto: use the LLM layer iff ANTHROPIC_API_KEY is set")
    ap.add_argument("--no-classify", action="store_true", help="skip classification (debugging)")
    ap.add_argument("--source-file", action="append", default=[], metavar="NAME=FILE",
                    help="override a source's file name, e.g. erp=new_erp.csv")
    a = ap.parse_args(argv)

    config = a.config
    if a.auto_config:
        from spendpipe.autoconfig import build_config
        config = build_config(a.auto_config, tag=a.tag)
        print(f"auto-config written to {config}; review it, then re-run with --config to freeze it", flush=True)
    if not config:
        ap.error("give --config or --auto-config")
    sf = dict(s.split("=", 1) for s in a.source_file)
    run(config, out_dir=a.out, name=a.name, tag=a.tag, data_dir=a.data_dir, labels=a.labels, llm=a.llm,
        no_classify=a.no_classify, source_files=sf or None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
